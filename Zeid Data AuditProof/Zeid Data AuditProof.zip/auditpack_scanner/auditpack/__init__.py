"""AuditPack - Compliance evidence scanner.

Policy-driven scanner that produces per-control evidence bundles, chain-of-custody hashes, and a zipped audit pack.
"""

from .version import __version__

__all__ = ["__version__"]
