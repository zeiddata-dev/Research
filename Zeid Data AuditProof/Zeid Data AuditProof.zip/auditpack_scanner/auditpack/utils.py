from __future__ import annotations

import base64
import dataclasses
import hashlib
import json
import os
import platform
import re
import socket
import sys
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple


def utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def local_now_iso() -> str:
    # Local time with offset
    return datetime.now().astimezone().isoformat()


def ensure_dir(p: Path) -> None:
    p.mkdir(parents=True, exist_ok=True)


def read_text_best_effort(data: bytes) -> str:
    # Prefer UTF-8; fall back to latin-1 to preserve bytes 0-255.
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError:
        return data.decode("latin-1", errors="replace")


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def json_dump(obj: Any, path: Path) -> None:
    path.write_text(json.dumps(obj, indent=2, sort_keys=True) + "\n", encoding="utf-8")


def json_dumps(obj: Any) -> str:
    return json.dumps(obj, indent=2, sort_keys=True)


def safe_filename(s: str) -> str:
    # Keep alnum, dash, underscore, dot
    return re.sub(r"[^A-Za-z0-9._-]+", "_", s).strip("_") or "item"


def host_fingerprint() -> Dict[str, Any]:
    # Non-secret host fingerprint for evidence provenance.
    # Avoid collecting sensitive identifiers (e.g., full disk serials).
    return {
        "hostname": socket.gethostname(),
        "fqdn": socket.getfqdn(),
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "version": platform.version(),
        "machine": platform.machine(),
        "python": sys.version.split()[0],
        "pid": os.getpid(),
    }


def run_id() -> str:
    # Stable ID per execution.
    # UUID4 is sufficient; encode as URL-safe base64 to keep short.
    raw = uuid.uuid4().bytes
    return base64.urlsafe_b64encode(raw).decode("ascii").rstrip("=")


@dataclasses.dataclass
class RedactionRule:
    pattern: str
    replace: str = "REDACTED"

    def apply(self, text: str) -> str:
        return re.sub(self.pattern, self.replace, text)


def apply_redactions(text: str, rules: Iterable[RedactionRule]) -> str:
    out = text
    for r in rules:
        out = r.apply(out)
    return out


def file_listing(root: Path, *, exclude_names: Optional[set[str]] = None) -> List[Path]:
    exclude_names = exclude_names or set()
    files: List[Path] = []
    for p in sorted(root.rglob("*")):
        if p.is_file() and p.name not in exclude_names:
            files.append(p)
    return files


def write_sha256_manifest(root: Path, manifest_path: Path, *, exclude_names: Optional[set[str]] = None) -> List[Tuple[str, str]]:
    """Write FILE_HASHES.sha256 style manifest: `<sha256>  <relative_path>`.

    Returns list of (rel_path, sha256).
    """
    exclude_names = exclude_names or set()
    entries: List[Tuple[str, str]] = []
    lines: List[str] = []
    for f in file_listing(root, exclude_names=exclude_names | {manifest_path.name}):
        rel = f.relative_to(root).as_posix()
        digest = sha256_file(f)
        entries.append((rel, digest))
        lines.append(f"{digest}  {rel}")
    manifest_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return entries


def monotonic_snapshot() -> Dict[str, Any]:
    return {
        "time.time": time.time(),
        "time.monotonic": time.monotonic(),
        "time.perf_counter": time.perf_counter(),
        "time.process_time": time.process_time(),
    }
