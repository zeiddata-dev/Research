from __future__ import annotations

import dataclasses
from pathlib import Path
from typing import Any, Dict, List, Optional

import yaml


@dataclasses.dataclass
class EvidenceStep:
    type: str
    id: str
    when: str = "any"  # any|linux|windows|darwin
    timeout_seconds: Optional[int] = None
    # arbitrary step settings stored here
    config: Dict[str, Any] = dataclasses.field(default_factory=dict)


@dataclasses.dataclass
class Control:
    id: str
    name: str
    description: str
    mappings: Dict[str, List[str]]
    evidence: List[EvidenceStep]


@dataclasses.dataclass
class PackMeta:
    org: str = ""
    system: str = ""
    owner: str = ""
    auditor: str = ""
    frameworks: List[str] = dataclasses.field(default_factory=list)


@dataclasses.dataclass
class Policy:
    policy_version: str
    pack: PackMeta
    controls: List[Control]


def _as_list(x: Any) -> List[Any]:
    if x is None:
        return []
    if isinstance(x, list):
        return x
    return [x]


def load_policy(path: Path) -> Policy:
    data = yaml.safe_load(path.read_text(encoding="utf-8"))
    if not isinstance(data, dict):
        raise ValueError("Policy root must be a mapping")

    pv = str(data.get("policy_version", "1.0"))
    pack_raw = data.get("pack", {}) or {}
    pack = PackMeta(
        org=str(pack_raw.get("org", "")),
        system=str(pack_raw.get("system", "")),
        owner=str(pack_raw.get("owner", "")),
        auditor=str(pack_raw.get("auditor", "")),
        frameworks=[str(x) for x in _as_list(pack_raw.get("frameworks", []))],
    )

    controls: List[Control] = []
    for idx, c in enumerate(data.get("controls", []) or []):
        if not isinstance(c, dict):
            raise ValueError(f"Control entry #{idx} must be a mapping")
        cid = str(c.get("id", "")).strip()
        if not cid:
            raise ValueError(f"Control entry #{idx} missing 'id'")
        name = str(c.get("name", "")).strip() or cid
        desc = str(c.get("description", "")).strip()
        mappings_raw = c.get("mappings", {}) or {}
        if not isinstance(mappings_raw, dict):
            raise ValueError(f"Control {cid}: mappings must be a mapping")
        mappings: Dict[str, List[str]] = {}
        for fw, vals in mappings_raw.items():
            mappings[str(fw)] = [str(v) for v in _as_list(vals)]

        ev_steps: List[EvidenceStep] = []
        for sidx, s in enumerate(c.get("evidence", []) or []):
            if not isinstance(s, dict):
                raise ValueError(f"Control {cid}: evidence step #{sidx} must be a mapping")
            stype = str(s.get("type", "")).strip()
            sid = str(s.get("id", "")).strip() or f"step_{sidx}"
            when = str(s.get("when", "any")).strip().lower()
            timeout = s.get("timeout_seconds", None)
            if timeout is not None:
                timeout = int(timeout)
            config = {k: v for k, v in s.items() if k not in {"type", "id", "when", "timeout_seconds"}}
            ev_steps.append(EvidenceStep(type=stype, id=sid, when=when, timeout_seconds=timeout, config=config))

        controls.append(Control(id=cid, name=name, description=desc, mappings=mappings, evidence=ev_steps))

    if not controls:
        raise ValueError("Policy must include at least one control")

    return Policy(policy_version=pv, pack=pack, controls=controls)
