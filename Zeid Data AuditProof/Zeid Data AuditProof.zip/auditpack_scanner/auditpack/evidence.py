from __future__ import annotations

import json
import os
import platform
import shutil
from dataclasses import asdict
from pathlib import Path
from typing import Any, Dict, List, Optional

from .collectors.base import EvidenceStepResult
from .policy import Control, EvidenceStep
from .utils import ensure_dir, file_listing, json_dump, local_now_iso, safe_filename, sha256_file, utc_now_iso, write_sha256_manifest


def platform_tag() -> str:
    sysname = platform.system().lower()
    if sysname.startswith("linux"):
        return "linux"
    if sysname.startswith("darwin"):
        return "darwin"
    if sysname.startswith("windows"):
        return "windows"
    return "unknown"


def step_applicable(step_when: str, plat: str) -> bool:
    w = (step_when or "any").lower()
    if w == "any":
        return True
    return w == plat


def build_control_bundle(
    *,
    root_dir: Path,
    control: Control,
    steps: List[EvidenceStep],
    step_results: List[EvidenceStepResult],
    run_meta: Dict[str, Any],
) -> Dict[str, Any]:
    """Finalize a control bundle.

    Writes:
      - normalized/control.json
      - NARRATIVE.md
      - TIMESTAMPS.json
      - FILE_HASHES.sha256
      - CHAIN_OF_CUSTODY.json

    Returns normalized summary dict.
    """

    ensure_dir(root_dir)
    raw_dir = root_dir / "raw"
    norm_dir = root_dir / "normalized"
    ensure_dir(raw_dir)
    ensure_dir(norm_dir)

    started_at_utc = run_meta.get("started_at_utc")
    ended_at_utc = utc_now_iso()

    # Determine control status (conservative): fail if any step fails; unknown if any unknown; else pass
    statuses = [r.status for r in step_results]
    if any(s == "fail" for s in statuses):
        control_status = "fail"
    elif any(s == "unknown" for s in statuses):
        control_status = "unknown"
    else:
        control_status = "pass"

    normalized = {
        "schema": "auditpack.control_result.v1",
        "control": {
            "id": control.id,
            "name": control.name,
            "description": control.description,
            "mappings": control.mappings,
        },
        "status": control_status,
        "collected_at_local": local_now_iso(),
        "collected_at_utc": ended_at_utc,
        "steps": [asdict(r) for r in step_results],
        "run": run_meta,
    }
    json_dump(normalized, norm_dir / "control.json")

    # Narrative
    narrative_lines: List[str] = []
    narrative_lines.append(f"# Evidence Narrative: {control.id} — {control.name}\n")
    if control.description:
        narrative_lines.append(f"**Control intent:** {control.description}\n")
    narrative_lines.append(f"**Result:** `{control_status.upper()}`\n")
    narrative_lines.append("## What was collected\n")
    for r in step_results:
        narrative_lines.append(f"- **{r.step_id}** (`{r.step_type}`): `{r.status}`")
        # Include a small, non-sensitive detail hint
        if r.step_type == "command":
            cmd = r.details.get("command")
            if cmd:
                narrative_lines.append(f"  - Command: `{cmd}`")
        if r.step_type in {"file_exists", "file_hash"}:
            narrative_lines.append(f"  - Path: `{r.details.get('path')}`")
    narrative_lines.append("\n## Mappings\n")
    for fw, refs in (control.mappings or {}).items():
        if refs:
            narrative_lines.append(f"- **{fw}**: {', '.join(refs)}")

    narrative_lines.append("\n## Auditor notes\n")
    narrative_lines.append(
        "This bundle contains raw artifacts under `raw/`, normalized findings under `normalized/`, and a chain-of-custody manifest."
    )
    (root_dir / "NARRATIVE.md").write_text("\n".join(narrative_lines) + "\n", encoding="utf-8")

    # Timestamps
    timestamps = {
        "schema": "auditpack.timestamps.v1",
        "control_id": control.id,
        "bundle_started_at_utc": started_at_utc,
        "bundle_ended_at_utc": ended_at_utc,
        "bundle_collected_at_local": local_now_iso(),
        "steps": [
            {
                "step_id": r.step_id,
                "started_at_utc": r.started_at_utc,
                "ended_at_utc": r.ended_at_utc,
                "collected_at_utc": r.collected_at_utc,
                "status": r.status,
            }
            for r in step_results
        ],
    }
    json_dump(timestamps, root_dir / "TIMESTAMPS.json")

    # Chain-of-custody: compute hashes for every file except the hash manifest itself
    file_hashes_path = root_dir / "FILE_HASHES.sha256"
    entries = write_sha256_manifest(root_dir, file_hashes_path)
    manifest_hash = sha256_file(file_hashes_path)

    coc = {
        "schema": "auditpack.chain_of_custody.v1",
        "control_id": control.id,
        "bundle_path": root_dir.name,
        "generated_at_utc": utc_now_iso(),
        "generated_at_local": local_now_iso(),
        "manifest_file": file_hashes_path.name,
        "manifest_sha256": manifest_hash,
        "evidence_files": [
            {"relative_path": rel, "sha256": digest} for (rel, digest) in entries
        ],
        "run": run_meta,
    }
    json_dump(coc, root_dir / "CHAIN_OF_CUSTODY.json")

    return {
        "control_id": control.id,
        "status": control_status,
        "bundle_dir": root_dir.name,
        "normalized": "normalized/control.json",
        "narrative": "NARRATIVE.md",
        "timestamps": "TIMESTAMPS.json",
        "chain_of_custody": "CHAIN_OF_CUSTODY.json",
        "file_hashes": "FILE_HASHES.sha256",
    }


def zip_dir(src_dir: Path, zip_path: Path) -> None:
    # shutil.make_archive wants base_name without suffix
    base = zip_path
    if base.suffix.lower() == ".zip":
        base = base.with_suffix("")
    ensure_dir(zip_path.parent)
    shutil.make_archive(str(base), "zip", root_dir=str(src_dir))

