from __future__ import annotations

import argparse
import os
import platform
import sys
from pathlib import Path
from typing import Any, Dict, List, Optional

from . import __version__
from .collectors.command import CommandCollector
from .collectors.file import FileExistsCollector, FileHashCollector
from .collectors.osinfo import OSInfoCollector
from .collectors.base import Collector, EvidenceStepResult
from .evidence import build_control_bundle, platform_tag, step_applicable, zip_dir
from .policy import load_policy, Policy, Control, EvidenceStep
from .report import generate_executive_summary
from .utils import ensure_dir, host_fingerprint, json_dump, local_now_iso, run_id, sha256_file, utc_now_iso, write_sha256_manifest


COLLECTORS: Dict[str, Collector] = {
    "command": CommandCollector(),
    "file_exists": FileExistsCollector(),
    "file_hash": FileHashCollector(),
    "os_info": OSInfoCollector(),
}


def _hash_tool_source(root: Path) -> Dict[str, Any]:
    # Hash all .py files under package for provenance.
    pkg_dir = root / "auditpack"
    files = sorted([p for p in pkg_dir.rglob("*.py") if p.is_file()])
    return {
        "schema": "auditpack.tool_integrity.v1",
        "tool_version": __version__,
        "python": sys.version.split()[0],
        "files": [
            {
                "path": str(p.relative_to(root)).replace("\\\\", "/"),
                "sha256": sha256_file(p),
            }
            for p in files
        ],
    }


def cmd_run(argv: Optional[List[str]] = None) -> int:
    ap = argparse.ArgumentParser(prog="auditpack", description="Policy-driven compliance evidence scanner")
    ap.add_argument("run", nargs="?", help=argparse.SUPPRESS)
    ap.add_argument("--policy", required=True, help="Path to policy YAML")
    ap.add_argument("--out", default="./out", help="Output directory (default: ./out)")
    ap.add_argument("--pack-name", default=None, help="Optional pack name prefix")
    ap.add_argument("--timeout-seconds", type=int, default=30, help="Default timeout for command steps")
    ap.add_argument("--no-zip", action="store_true", help="Do not create a .zip")

    args = ap.parse_args(argv)

    policy_path = Path(args.policy).expanduser().resolve()
    out_base = Path(args.out).expanduser().resolve()
    ensure_dir(out_base)

    pol = load_policy(policy_path)
    plat = platform_tag()

    rid = run_id()
    started_utc = utc_now_iso()

    # Pack root
    stamp = started_utc.replace(":", "").replace("-", "").split("+")[0].replace("T", "_")
    name = args.pack_name or "auditpack"
    pack_dir = out_base / f"{name}_{stamp}"
    ensure_dir(pack_dir)

    # Write run metadata & tool integrity
    run_meta = {
        "schema": "auditpack.run_meta.v1",
        "run_id": rid,
        "tool": {"name": "auditpack", "version": __version__},
        "platform_tag": plat,
        "host": host_fingerprint(),
        "policy": {
            "path": str(policy_path),
            "sha256": sha256_file(policy_path),
            "policy_version": pol.policy_version,
        },
        "started_at_utc": started_utc,
        "started_at_local": local_now_iso(),
    }
    json_dump(run_meta, pack_dir / "RUN_META.json")

    tool_integrity = _hash_tool_source(Path(__file__).resolve().parents[1])
    json_dump(tool_integrity, pack_dir / "TOOL_INTEGRITY.json")

    pack_meta = {
        "org": pol.pack.org,
        "system": pol.pack.system,
        "owner": pol.pack.owner,
        "auditor": pol.pack.auditor,
        "frameworks": pol.pack.frameworks,
    }
    json_dump(pack_meta, pack_dir / "PACK_META.json")

    control_summaries: List[Dict[str, Any]] = []

    controls_root = pack_dir / "controls"
    ensure_dir(controls_root)

    for control in pol.controls:
        cdir = controls_root / f"{control.id}__{safe_control_name(control.name)}"
        ensure_dir(cdir)
        ensure_dir(cdir / "raw")
        ensure_dir(cdir / "normalized")

        step_results: List[EvidenceStepResult] = []

        for step in control.evidence:
            if not step_applicable(step.when, plat):
                # record as unknown (not applicable)
                step_results.append(
                    EvidenceStepResult(
                        step_id=step.id,
                        step_type=step.type,
                        status="unknown",
                        collected_at_utc=utc_now_iso(),
                        started_at_utc=utc_now_iso(),
                        ended_at_utc=utc_now_iso(),
                        details={"reason": f"step_when={step.when} not applicable to platform={plat}"},
                        artifacts=[],
                    )
                )
                continue

            collector = COLLECTORS.get(step.type)
            if not collector:
                step_results.append(
                    EvidenceStepResult(
                        step_id=step.id,
                        step_type=step.type,
                        status="unknown",
                        collected_at_utc=utc_now_iso(),
                        started_at_utc=utc_now_iso(),
                        ended_at_utc=utc_now_iso(),
                        details={"reason": f"unknown step type '{step.type}'"},
                        artifacts=[],
                    )
                )
                continue

            timeout = step.timeout_seconds if step.timeout_seconds is not None else args.timeout_seconds

            try:
                r = collector.run(
                    step_id=step.id,
                    config=step.config,
                    raw_dir=cdir / "raw",
                    timeout_seconds=timeout,
                    platform_tag=plat,
                )
            except Exception as e:
                r = EvidenceStepResult(
                    step_id=step.id,
                    step_type=step.type,
                    status="fail",
                    collected_at_utc=utc_now_iso(),
                    started_at_utc=utc_now_iso(),
                    ended_at_utc=utc_now_iso(),
                    details={"exception": f"{type(e).__name__}: {e}"},
                    artifacts=[],
                )
            step_results.append(r)

        bundle_summary = build_control_bundle(
            root_dir=cdir,
            control=control,
            steps=control.evidence,
            step_results=step_results,
            run_meta=run_meta,
        )

        # include name/mappings for executive summary
        bundle_summary.update({"name": control.name, "mappings": control.mappings})
        control_summaries.append(bundle_summary)

    # finalize run
    ended_utc = utc_now_iso()
    run_meta["ended_at_utc"] = ended_utc
    run_meta["ended_at_local"] = local_now_iso()
    json_dump(run_meta, pack_dir / "RUN_META.json")

    # executive summary
    generate_executive_summary(out_dir=pack_dir, pack_meta=pack_meta, run_meta=run_meta, control_summaries=control_summaries)

    # pack chain-of-custody at root
    pack_hashes = pack_dir / "PACK_HASHES.sha256"
    entries = write_sha256_manifest(pack_dir, pack_hashes)
    json_dump(
        {
            "schema": "auditpack.pack_chain_of_custody.v1",
            "generated_at_utc": utc_now_iso(),
            "pack_dir": pack_dir.name,
            "manifest_file": pack_hashes.name,
            "manifest_sha256": sha256_file(pack_hashes),
            "files": [{"relative_path": rel, "sha256": digest} for (rel, digest) in entries],
            "run": run_meta,
        },
        pack_dir / "PACK_CHAIN_OF_CUSTODY.json",
    )

    # zip
    if not args.no_zip:
        zip_path = out_base / f"{pack_dir.name}.zip"
        zip_dir(pack_dir, zip_path)
        # hash the zip
        (out_base / f"{pack_dir.name}.zip.sha256").write_text(f"{sha256_file(zip_path)}  {zip_path.name}\n", encoding="utf-8")

    print(f"AuditPack written to: {pack_dir}")
    if not args.no_zip:
        print(f"Zipped audit pack:    {out_base / (pack_dir.name + '.zip')}")

    return 0


def safe_control_name(name: str) -> str:
    # Keep folder names stable and readable
    from .utils import safe_filename

    return safe_filename(name)[:60]


def main() -> None:
    # support `auditpack run ...` and `auditpack ...` for convenience
    argv = sys.argv[1:]
    if argv and argv[0] == "run":
        argv = argv[1:]
    code = cmd_run(argv)
    raise SystemExit(code)
