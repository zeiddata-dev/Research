from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Dict, Optional

from ..utils import host_fingerprint, local_now_iso, monotonic_snapshot, utc_now_iso
from .base import Collector, EvidenceArtifact, EvidenceStepResult


class OSInfoCollector(Collector):
    """Collects basic OS and runtime provenance info.

    Policy example:
      - type: os_info
        id: provenance
    """

    def run(
        self,
        *,
        step_id: str,
        config: Dict[str, Any],
        raw_dir: Path,
        timeout_seconds: Optional[int],
        platform_tag: str,
    ) -> EvidenceStepResult:
        started = utc_now_iso()
        meta_path = raw_dir / f"{step_id}.osinfo.json"
        doc = {
            "step_id": step_id,
            "type": "os_info",
            "platform_tag": platform_tag,
            "host": host_fingerprint(),
            "clock": monotonic_snapshot(),
            "collected_at_local": local_now_iso(),
            "collected_at_utc": started,
        }
        meta_path.write_text(json.dumps(doc, indent=2, sort_keys=True) + "\n", encoding="utf-8")
        ended = utc_now_iso()
        artifacts = [EvidenceArtifact(relpath=f"raw/{meta_path.name}", mime="application/json")]
        return EvidenceStepResult(
            step_id=step_id,
            step_type="os_info",
            status="pass",
            collected_at_utc=ended,
            started_at_utc=started,
            ended_at_utc=ended,
            details={"host": doc["host"]},
            artifacts=artifacts,
        )
