from __future__ import annotations

import json
import os
import subprocess
from pathlib import Path
from typing import Any, Dict, Optional

from ..utils import apply_redactions, local_now_iso, read_text_best_effort, utc_now_iso
from .base import Collector, EvidenceArtifact, EvidenceStepResult
from ..utils import RedactionRule


class CommandCollector(Collector):
    """Runs a command and captures stdout/stderr/exit code.

    Policy example:
      - type: command
        id: check_journald
        command: ["systemctl", "status", "systemd-journald"]
        timeout_seconds: 15
        expect_exit_codes: [0]
        redaction:
          - pattern: "(?i)password=\S+"
            replace: "password=REDACTED"
    """

    def run(
        self,
        *,
        step_id: str,
        config: Dict[str, Any],
        raw_dir: Path,
        timeout_seconds: Optional[int],
        platform_tag: str,
    ) -> EvidenceStepResult:
        started = utc_now_iso()
        cmd = config.get("command")
        if not cmd:
            raise ValueError(f"command step {step_id} missing 'command'")
        if isinstance(cmd, str):
            # allow string but run via shell=False by splitting is ambiguous; require list for safety
            raise ValueError(f"command step {step_id} must use list form, e.g. ['whoami']")
        if not isinstance(cmd, list) or not all(isinstance(x, str) for x in cmd):
            raise ValueError(f"command step {step_id}: 'command' must be a list of strings")

        cwd = config.get("cwd", None)
        env = config.get("env", {}) or {}
        if not isinstance(env, dict):
            raise ValueError(f"command step {step_id}: env must be a mapping")

        redaction_rules = []
        for r in config.get("redaction", []) or []:
            if not isinstance(r, dict) or "pattern" not in r:
                continue
            redaction_rules.append(RedactionRule(pattern=str(r["pattern"]), replace=str(r.get("replace", "REDACTED"))))

        expect_exit_codes = config.get("expect_exit_codes", [0])
        if isinstance(expect_exit_codes, int):
            expect_exit_codes = [expect_exit_codes]
        expect_exit_codes = [int(x) for x in (expect_exit_codes or [])]

        # Execute
        proc = subprocess.run(
            cmd,
            cwd=str(cwd) if cwd else None,
            env={**os.environ, **{str(k): str(v) for k, v in env.items()}},
            capture_output=True,
            timeout=timeout_seconds,
            check=False,
            shell=False,
        )

        stdout = read_text_best_effort(proc.stdout)
        stderr = read_text_best_effort(proc.stderr)
        stdout = apply_redactions(stdout, redaction_rules)
        stderr = apply_redactions(stderr, redaction_rules)

        # Write raw artifacts
        out_path = raw_dir / f"{step_id}.stdout.txt"
        err_path = raw_dir / f"{step_id}.stderr.txt"
        meta_path = raw_dir / f"{step_id}.meta.json"
        out_path.write_text(stdout, encoding="utf-8")
        err_path.write_text(stderr, encoding="utf-8")

        meta = {
            "step_id": step_id,
            "type": "command",
            "command": cmd,
            "cwd": cwd,
            "exit_code": proc.returncode,
            "timeout_seconds": timeout_seconds,
            "collected_at_local": local_now_iso(),
            "platform_tag": platform_tag,
        }
        meta_path.write_text(json.dumps(meta, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        status = "pass" if proc.returncode in set(expect_exit_codes) else "fail"
        ended = utc_now_iso()

        artifacts = [
            EvidenceArtifact(relpath=f"raw/{out_path.name}", mime="text/plain"),
            EvidenceArtifact(relpath=f"raw/{err_path.name}", mime="text/plain"),
            EvidenceArtifact(relpath=f"raw/{meta_path.name}", mime="application/json"),
        ]

        details: Dict[str, Any] = {
            "command": cmd,
            "exit_code": proc.returncode,
            "expected_exit_codes": expect_exit_codes,
            "stdout_path": f"raw/{out_path.name}",
            "stderr_path": f"raw/{err_path.name}",
        }

        return EvidenceStepResult(
            step_id=step_id,
            step_type="command",
            status=status,
            collected_at_utc=ended,
            started_at_utc=started,
            ended_at_utc=ended,
            details=details,
            artifacts=artifacts,
        )
