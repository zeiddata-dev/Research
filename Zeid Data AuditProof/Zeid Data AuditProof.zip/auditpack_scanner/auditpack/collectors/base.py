from __future__ import annotations

import abc
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Optional


@dataclass
class EvidenceArtifact:
    """A single evidence artifact produced by a collector.

    Artifacts are written into the per-control bundle under `raw/` and referenced from normalized JSON.
    """

    relpath: str
    sha256: Optional[str] = None
    bytes_written: Optional[int] = None
    mime: str = "application/octet-stream"


@dataclass
class EvidenceStepResult:
    step_id: str
    step_type: str
    status: str  # pass|fail|unknown
    collected_at_utc: str
    started_at_utc: str
    ended_at_utc: str
    details: Dict[str, Any]
    artifacts: list[EvidenceArtifact]


class Collector(abc.ABC):
    @abc.abstractmethod
    def run(
        self,
        *,
        step_id: str,
        config: Dict[str, Any],
        raw_dir: Path,
        timeout_seconds: Optional[int],
        platform_tag: str,
    ) -> EvidenceStepResult:
        raise NotImplementedError
