from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from ..utils import local_now_iso, sha256_file, utc_now_iso
from .base import Collector, EvidenceArtifact, EvidenceStepResult


class FileExistsCollector(Collector):
    """Checks whether a file exists and records stat metadata.

    Policy example:
      - type: file_exists
        id: sshd_config
        path: /etc/ssh/sshd_config
    """

    def run(
        self,
        *,
        step_id: str,
        config: Dict[str, Any],
        raw_dir: Path,
        timeout_seconds: Optional[int],
        platform_tag: str,
    ) -> EvidenceStepResult:
        started = utc_now_iso()
        path = config.get("path")
        if not path:
            raise ValueError(f"file_exists step {step_id} missing 'path'")
        p = Path(str(path))
        meta_path = raw_dir / f"{step_id}.file.json"

        exists = p.exists()
        details: Dict[str, Any] = {
            "path": str(p),
            "exists": exists,
            "platform_tag": platform_tag,
            "collected_at_local": local_now_iso(),
        }
        if exists:
            st = p.stat()
            details.update(
                {
                    "size_bytes": st.st_size,
                    "mtime": st.st_mtime,
                    "mode": oct(st.st_mode),
                }
            )
        meta_path.write_text(json.dumps(details, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        ended = utc_now_iso()
        status = "pass" if exists else "fail"

        artifacts = [EvidenceArtifact(relpath=f"raw/{meta_path.name}", mime="application/json")]
        return EvidenceStepResult(
            step_id=step_id,
            step_type="file_exists",
            status=status,
            collected_at_utc=ended,
            started_at_utc=started,
            ended_at_utc=ended,
            details={"path": str(p), "exists": exists},
            artifacts=artifacts,
        )


class FileHashCollector(Collector):
    """Hashes a file (sha256) and records stat metadata.

    Policy example:
      - type: file_hash
        id: sshd_config_hash
        path: /etc/ssh/sshd_config
    """

    def run(
        self,
        *,
        step_id: str,
        config: Dict[str, Any],
        raw_dir: Path,
        timeout_seconds: Optional[int],
        platform_tag: str,
    ) -> EvidenceStepResult:
        started = utc_now_iso()
        path = config.get("path")
        if not path:
            raise ValueError(f"file_hash step {step_id} missing 'path'")
        p = Path(str(path))
        meta_path = raw_dir / f"{step_id}.filehash.json"

        exists = p.exists()
        sha = None
        details: Dict[str, Any] = {
            "path": str(p),
            "exists": exists,
            "platform_tag": platform_tag,
            "collected_at_local": local_now_iso(),
        }
        if exists and p.is_file():
            st = p.stat()
            sha = sha256_file(p)
            details.update(
                {
                    "size_bytes": st.st_size,
                    "mtime": st.st_mtime,
                    "mode": oct(st.st_mode),
                    "sha256": sha,
                }
            )
        meta_path.write_text(json.dumps(details, indent=2, sort_keys=True) + "\n", encoding="utf-8")

        ended = utc_now_iso()
        status = "pass" if exists and sha else "fail"
        artifacts = [EvidenceArtifact(relpath=f"raw/{meta_path.name}", mime="application/json")]
        return EvidenceStepResult(
            step_id=step_id,
            step_type="file_hash",
            status=status,
            collected_at_utc=ended,
            started_at_utc=started,
            ended_at_utc=ended,
            details={"path": str(p), "exists": exists, "sha256": sha},
            artifacts=artifacts,
        )
