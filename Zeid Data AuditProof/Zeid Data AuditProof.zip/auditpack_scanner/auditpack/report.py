from __future__ import annotations

import json
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path
from typing import Any, Dict, List

from .utils import json_dump, local_now_iso, utc_now_iso


def generate_executive_summary(
    *,
    out_dir: Path,
    pack_meta: Dict[str, Any],
    run_meta: Dict[str, Any],
    control_summaries: List[Dict[str, Any]],
) -> Dict[str, Any]:
    """Create an executive summary at the root of the audit pack.

    Writes:
      - EXECUTIVE_SUMMARY.md
      - executive_summary.json
    """

    counts = Counter([c.get("status", "unknown") for c in control_summaries])

    # Framework rollups: control -> mappings
    framework_hits = defaultdict(lambda: {"pass": 0, "fail": 0, "unknown": 0, "controls": []})

    for c in control_summaries:
        cid = c.get("control_id")
        status = c.get("status", "unknown")
        mappings = c.get("mappings", {}) or {}
        for fw, refs in mappings.items():
            framework_hits[fw][status] += 1
            framework_hits[fw]["controls"].append({"control_id": cid, "status": status, "refs": refs})

    summary = {
        "schema": "auditpack.executive_summary.v1",
        "generated_at_utc": utc_now_iso(),
        "generated_at_local": local_now_iso(),
        "pack": pack_meta,
        "run": run_meta,
        "totals": dict(counts),
        "frameworks": framework_hits,
        "controls": control_summaries,
    }

    json_dump(summary, out_dir / "executive_summary.json")

    # Markdown
    lines: List[str] = []
    lines.append(f"# Executive Summary — AuditPack\n")
    org = pack_meta.get("org", "")
    system = pack_meta.get("system", "")
    lines.append(f"**Organization:** {org or '—'}")
    lines.append(f"**System / Scope:** {system or '—'}")
    lines.append(f"**Run ID:** `{run_meta.get('run_id','')}`")
    lines.append(f"**Collected at (UTC):** `{run_meta.get('ended_at_utc','')}`\n")

    lines.append("## Overall results")
    lines.append(f"- PASS: **{counts.get('pass',0)}**")
    lines.append(f"- FAIL: **{counts.get('fail',0)}**")
    lines.append(f"- UNKNOWN: **{counts.get('unknown',0)}**\n")

    lines.append("## Controls")
    for c in control_summaries:
        lines.append(f"- `{c['control_id']}`: **{c['status'].upper()}** — {c.get('name','')}")

    if framework_hits:
        lines.append("\n## Framework rollups")
        for fw, d in framework_hits.items():
            lines.append(f"### {fw}")
            lines.append(f"- PASS: {d['pass']}  |  FAIL: {d['fail']}  |  UNKNOWN: {d['unknown']}")

    lines.append("\n## Deliverables")
    lines.append("This audit pack contains per-control evidence bundles (raw artifacts + normalized JSON + narratives) and chain-of-custody manifests (SHA-256).")

    (out_dir / "EXECUTIVE_SUMMARY.md").write_text("\n".join(lines) + "\n", encoding="utf-8")

    return summary
