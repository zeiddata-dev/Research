# Changelog

## 0.1.0
- Initial release:
  - 3 dashboard templates (Overview, Policy, Exposure Signals)
  - 6 saved searches (presence check + evidence queries)
  - 3 lookup files (AI domains, AI apps, data-movement tools)
