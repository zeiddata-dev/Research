# Tuning Notes

## 1) Domain Matching
The `match()` lookup in this package uses **exact** matching.
- Add the exact subdomains you observe (e.g., `chat.openai.com`, not just `openai.com`).
- If your telemetry stores FQDNs differently (lower/upper, trailing dot), normalize as needed.

## 2) Process Matching
If `ImageFileName` contains a full path, the exact `match()` may not hit.
Options:
- Adjust the query to extract basename before the match.
- Update the lookup file to include the observed full path(s).

## 3) “New AI Domains”
The “candidate” widget is keyword-based and will require tuning (false positives/negatives).
For stronger results, combine with:
- proxy logs
- CASB
- firewall DNS logs
