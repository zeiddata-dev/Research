# Field Mapping Quick Reference

This package expects CrowdStrike telemetry in Falcon LogScale / NG-SIEM.

Common fields used in queries (adjust to your schema if needed):

## Event Type
- `#event_simpleName`
  - Examples used:
    - `DnsRequest`
    - `ProcessRollup2`
    - `NetworkConnectIP4`

## Identity
- `ComputerName` (host)
- `UserName` (user)

## DNS
- `DomainName` (queried domain)

## Process
- `ImageFileName` (executable name)

## Network Connect
- `RemoteAddressIP4` (destination IP)
- `RemotePort` (destination port)

If your fields differ, open the saved searches or dashboard templates and replace these references.
