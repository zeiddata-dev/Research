# Secure Firewall (FMC/FTD) — objects & policy (firewall telemetry)

## Objects to create
Create URL / FQDN objects (or a URL category custom list) for:
- claude.ai
- *.claude.ai
- api.anthropic.com
- *.anthropic.com
- code.claude.com
- platform.claude.com
- console.anthropic.com

## Detection-first rule (recommended)
Create an Access Control rule:
- Action: ALLOW (detection mode)
- Source zones: user/server egress zones
- Destination: the FQDN objects above
- Destination port: 443
- Logging: log at beginning + end
- Metadata: tag as "AI_SAAS_CLAUDE"

## IDS/IPS alerting without blocking
Import `snort3/claude_sni.rules` as CUSTOM rules into the IPS policy.
- Set action: ALERT
- Log events to FMC and forward to SIEM

## Enforcement option (only if approved)
Switch the Access Control rule action to BLOCK or set Snort action to DROP.
Keep logging enabled.
