# Reports & dashboards (Cisco-side)

This file provides **templates** for reports you can build from firewall + IPS events.

## Daily summary report (firewall egress)
Include:
- hourly trend
- top source IPs / users
- top destination domains
- allow vs block ratio
- bytes in/out and connection counts

## IPS alert report (Snort SNI matches)
Include:
- timestamp
- src IP
- dst IP/port
- rule message / SID
- count per source (top talkers)

## High-risk focus
Filter:
- destination = api.anthropic.com OR *.anthropic.com
- source zones = servers / production segments
- repeated hits over short windows
