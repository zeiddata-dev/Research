-- Snowflake AI Governance & Compliance Query Pack (20 queries)
-- Generated: 2026-01-26

-- Tip: ACCOUNT_USAGE can lag ~60–90 minutes. ACCESS_HISTORY availability varies by edition/config.

-- ============================================================================
-- Q01: Inventory Cortex/LLM usage (likely calls) in last 30 days
-- Notes: Heuristic detection via QUERY_TEXT patterns. Tune patterns to your org.
-- ============================================================================
SELECT
  USER_NAME,
  ROLE_NAME,
  WAREHOUSE_NAME,
  COUNT(*) AS calls,
  MIN(START_TIME) AS first_seen,
  MAX(START_TIME) AS last_seen
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND (
    QUERY_TEXT ILIKE '%SNOWFLAKE.CORTEX%'
    OR QUERY_TEXT ILIKE '% CORTEX_%'
    OR QUERY_TEXT ILIKE '%LLM%'
    OR QUERY_TEXT ILIKE '%EMBED%'
  )
GROUP BY 1,2,3
ORDER BY calls DESC;

-- ============================================================================
-- Q02: Top 50 Cortex/LLM calls by estimated prompt size (query text length)
-- Notes: Preview is truncated to reduce accidental prompt exposure in exports.
-- ============================================================================
SELECT
  QUERY_ID,
  USER_NAME,
  ROLE_NAME,
  START_TIME,
  LENGTH(QUERY_TEXT) AS query_text_len,
  LEFT(QUERY_TEXT, 500) AS query_preview_500
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND (QUERY_TEXT ILIKE '%SNOWFLAKE.CORTEX%' OR QUERY_TEXT ILIKE '% CORTEX_%')
ORDER BY query_text_len DESC
LIMIT 50;

-- ============================================================================
-- Q03: Cortex/LLM usage with many string literals (possible prompt leakage)
-- Notes: High quote count can indicate prompts embedded directly in SQL.
-- ============================================================================
SELECT
  QUERY_ID,
  USER_NAME,
  ROLE_NAME,
  START_TIME,
  (LENGTH(QUERY_TEXT) - LENGTH(REPLACE(QUERY_TEXT, '''', ''))) AS single_quote_count,
  LEFT(QUERY_TEXT, 500) AS query_preview_500
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND (QUERY_TEXT ILIKE '%SNOWFLAKE.CORTEX%' OR QUERY_TEXT ILIKE '% CORTEX_%')
  AND (LENGTH(QUERY_TEXT) - LENGTH(REPLACE(QUERY_TEXT, '''', ''))) >= 20
ORDER BY single_quote_count DESC, START_TIME DESC;

-- ============================================================================
-- Q04: Cortex/LLM queries + data objects accessed (requires ACCESS_HISTORY)
-- Notes: If ACCESS_HISTORY isn’t available, skip or approximate with QUERY_HISTORY.
-- ============================================================================
WITH cortex_q AS (
  SELECT QUERY_ID, USER_NAME, ROLE_NAME, START_TIME
  FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
  WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
    AND (QUERY_TEXT ILIKE '%SNOWFLAKE.CORTEX%' OR QUERY_TEXT ILIKE '% CORTEX_%')
)
SELECT
  q.QUERY_ID,
  q.USER_NAME,
  q.ROLE_NAME,
  q.START_TIME,
  o.value:"objectName"::STRING   AS object_name,
  o.value:"objectDomain"::STRING AS object_domain
FROM cortex_q q
JOIN SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY ah
  ON ah.QUERY_ID = q.QUERY_ID
, LATERAL FLATTEN(input => ah.BASE_OBJECTS_ACCESSED) o
ORDER BY q.START_TIME DESC;

-- ============================================================================
-- Q05: External function / API-like query usage signals (text heuristic)
-- Notes: Helps spot calls that might move data to external services.
-- ============================================================================
SELECT
  USER_NAME,
  ROLE_NAME,
  COUNT(*) AS suspected_external_calls,
  MIN(START_TIME) AS first_seen,
  MAX(START_TIME) AS last_seen
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND (
    QUERY_TEXT ILIKE '%EXTERNAL FUNCTION%'
    OR QUERY_TEXT ILIKE '%API_INTEGRATION%'
    OR QUERY_TEXT ILIKE '%CREATE EXTERNAL FUNCTION%'
  )
GROUP BY 1,2
ORDER BY suspected_external_calls DESC;

-- ============================================================================
-- Q06: COPY INTO to external URLs (S3/Azure/GCS) in last 30 days
-- Notes: Strong egress signal. Tune patterns for your naming/stages.
-- ============================================================================
SELECT
  QUERY_ID,
  USER_NAME,
  ROLE_NAME,
  START_TIME,
  END_TIME,
  TOTAL_ELAPSED_TIME/1000 AS elapsed_s,
  BYTES_SCANNED,
  ROWS_PRODUCED,
  LEFT(QUERY_TEXT, 1000) AS query_preview_1000
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND QUERY_TEXT ILIKE 'COPY INTO%'
  AND (
    QUERY_TEXT ILIKE '%s3://%'
    OR QUERY_TEXT ILIKE '%azure://%'
    OR QUERY_TEXT ILIKE '%gcs://%'
  )
ORDER BY START_TIME DESC;

-- ============================================================================
-- Q07: GET/PUT usage (staging data movement signals) in last 30 days
-- Notes: Good for workstation-driven exfil patterns.
-- ============================================================================
SELECT
  QUERY_ID,
  USER_NAME,
  ROLE_NAME,
  START_TIME,
  LEFT(QUERY_TEXT, 800) AS query_preview_800
FROM SNOWFLAKE.ACCOUNT_USAGE.QUERY_HISTORY
WHERE START_TIME >= DATEADD('day', -30, CURRENT_TIMESTAMP())
  AND (
    QUERY_TEXT ILIKE 'GET @%'
    OR QUERY_TEXT ILIKE 'PUT file://%'
  )
ORDER BY START_TIME DESC;

-- ============================================================================
-- Q08: Inventory external stages + owners (egress paths)
-- ============================================================================
SELECT
  STAGE_CATALOG AS database_name,
  STAGE_SCHEMA  AS schema_name,
  STAGE_NAME    AS stage_name,
  URL           AS stage_url,
  STORAGE_INTEGRATION,
  OWNER,
  CREATED
FROM SNOWFLAKE.ACCOUNT_USAGE.STAGES
WHERE URL IS NOT NULL
ORDER BY CREATED DESC;

-- ============================================================================
-- Q09: Outbound shares inventory (if ACCOUNT_USAGE.SHARES exists)
-- Notes: If missing, run `SHOW SHARES;` in Snowsight.
-- ============================================================================
SELECT
  SHARE_NAME,
  CREATED,
  OWNER,
  COMMENT
FROM SNOWFLAKE.ACCOUNT_USAGE.SHARES
ORDER BY CREATED DESC;

-- ============================================================================
-- Q10: Data transfer history by day (if DATA_TRANSFER_HISTORY exists)
-- Notes: If missing, lean on Q06 + Q08.
-- ============================================================================
SELECT
  START_TIME::DATE AS day,
  SOURCE_CLOUD,
  TARGET_CLOUD,
  SOURCE_REGION,
  TARGET_REGION,
  SUM(BYTES_TRANSFERRED) AS bytes_transferred
FROM SNOWFLAKE.ACCOUNT_USAGE.DATA_TRANSFER_HISTORY
WHERE START_TIME >= DATEADD('day', -90, CURRENT_TIMESTAMP())
GROUP BY 1,2,3,4,5
ORDER BY day DESC, bytes_transferred DESC;

-- ============================================================================
-- Q11: Privileged users (ACCOUNTADMIN/SECURITYADMIN/SYSADMIN)
-- ============================================================================
WITH role_grants AS (
  SELECT GRANTEE_NAME AS user_name, ROLE AS role_name
  FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS
  WHERE DELETED_ON IS NULL
)
SELECT
  user_name,
  LISTAGG(role_name, ', ') WITHIN GROUP (ORDER BY role_name) AS roles
FROM role_grants
WHERE role_name IN ('ACCOUNTADMIN', 'SECURITYADMIN', 'SYSADMIN')
GROUP BY 1
ORDER BY 1;

-- ============================================================================
-- Q12: Roles with high-risk privileges (grants, policies, integrations)
-- ============================================================================
SELECT
  GRANTEE_NAME AS role_name,
  PRIVILEGE,
  GRANTED_ON,
  NAME AS object_name,
  GRANTED_BY,
  CREATED_ON
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE DELETED_ON IS NULL
  AND PRIVILEGE IN (
    'MANAGE GRANTS',
    'OWNERSHIP',
    'APPLY MASKING POLICY',
    'APPLY ROW ACCESS POLICY',
    'CREATE INTEGRATION',
    'CREATE NETWORK POLICY'
  )
ORDER BY CREATED_ON DESC;

-- ============================================================================
-- Q13: New high-risk grants created in last 7 days (roles)
-- Notes: Good “control drift” detector.
-- ============================================================================
SELECT
  GRANTEE_NAME AS role_name,
  PRIVILEGE,
  GRANTED_ON,
  NAME AS object_name,
  GRANTED_BY,
  CREATED_ON
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_ROLES
WHERE CREATED_ON >= DATEADD('day', -7, CURRENT_TIMESTAMP())
  AND DELETED_ON IS NULL
  AND (
    PRIVILEGE IN ('OWNERSHIP','MANAGE GRANTS','CREATE INTEGRATION','CREATE NETWORK POLICY')
    OR PRIVILEGE ILIKE '%MASKING%'
    OR PRIVILEGE ILIKE '%ROW ACCESS%'
  )
ORDER BY CREATED_ON DESC;

-- ============================================================================
-- Q14: Direct object grants to users (anti-pattern)
-- Notes: Prefer grants to roles; direct grants complicate audits and offboarding.
-- ============================================================================
SELECT
  GRANTEE_NAME AS user_name,
  PRIVILEGE,
  GRANTED_ON,
  NAME AS object_name,
  GRANTED_BY,
  CREATED_ON
FROM SNOWFLAKE.ACCOUNT_USAGE.GRANTS_TO_USERS
WHERE DELETED_ON IS NULL
  AND GRANTED_ON IN ('DATABASE','SCHEMA','TABLE','VIEW','FUNCTION','PROCEDURE','STAGE')
ORDER BY CREATED_ON DESC;

-- ============================================================================
-- Q15: Dormant enabled users: no successful login in 90 days
-- ============================================================================
WITH last_login AS (
  SELECT USER_NAME, MAX(EVENT_TIMESTAMP) AS last_login
  FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
  WHERE EVENT_TIMESTAMP >= DATEADD('day', -365, CURRENT_TIMESTAMP())
    AND IS_SUCCESS = 'YES'
  GROUP BY 1
)
SELECT
  u.NAME AS user_name,
  u.DISABLED,
  u.CREATED_ON,
  l.last_login
FROM SNOWFLAKE.ACCOUNT_USAGE.USERS u
LEFT JOIN last_login l
  ON l.USER_NAME = u.NAME
WHERE u.DISABLED = 'FALSE'
  AND (l.last_login IS NULL OR l.last_login < DATEADD('day', -90, CURRENT_TIMESTAMP()))
ORDER BY l.last_login NULLS FIRST, u.CREATED_ON DESC;

-- ============================================================================
-- Q16: Login anomaly: new client IPs (last 7 days vs prior 180)
-- Notes: Tune for VPN allowlists to reduce noise.
-- ============================================================================
WITH recent AS (
  SELECT USER_NAME, CLIENT_IP,
         MIN(EVENT_TIMESTAMP) AS first_seen,
         MAX(EVENT_TIMESTAMP) AS last_seen,
         COUNT(*) AS login_count
  FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
  WHERE EVENT_TIMESTAMP >= DATEADD('day', -7, CURRENT_TIMESTAMP())
    AND IS_SUCCESS = 'YES'
  GROUP BY 1,2
),
baseline AS (
  SELECT DISTINCT USER_NAME, CLIENT_IP
  FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
  WHERE EVENT_TIMESTAMP >= DATEADD('day', -180, CURRENT_TIMESTAMP())
    AND EVENT_TIMESTAMP < DATEADD('day', -7, CURRENT_TIMESTAMP())
    AND IS_SUCCESS = 'YES'
)
SELECT
  r.USER_NAME,
  r.CLIENT_IP,
  r.first_seen,
  r.last_seen,
  r.login_count
FROM recent r
LEFT JOIN baseline b
  ON b.USER_NAME = r.USER_NAME AND b.CLIENT_IP = r.CLIENT_IP
WHERE b.CLIENT_IP IS NULL
ORDER BY r.first_seen DESC;

-- ============================================================================
-- Q17: Repeated failed logins (>=5) in last 7 days
-- ============================================================================
SELECT
  USER_NAME,
  CLIENT_IP,
  ERROR_MESSAGE,
  COUNT(*) AS failures,
  MIN(EVENT_TIMESTAMP) AS first_failure,
  MAX(EVENT_TIMESTAMP) AS last_failure
FROM SNOWFLAKE.ACCOUNT_USAGE.LOGIN_HISTORY
WHERE EVENT_TIMESTAMP >= DATEADD('day', -7, CURRENT_TIMESTAMP())
  AND IS_SUCCESS = 'NO'
GROUP BY 1,2,3
HAVING COUNT(*) >= 5
ORDER BY failures DESC, last_failure DESC;

-- ============================================================================
-- Q18: Sensitive tag inventory (PII/PHI/PCI/CONFIDENTIAL) using TAG_REFERENCES
-- Notes: If TAG_REFERENCES is missing, use INFORMATION_SCHEMA.TAG_REFERENCES per database.
-- ============================================================================
SELECT
  OBJECT_DATABASE,
  OBJECT_SCHEMA,
  OBJECT_NAME,
  COLUMN_NAME,
  TAG_DATABASE,
  TAG_SCHEMA,
  TAG_NAME,
  TAG_VALUE,
  CREATED
FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
WHERE (TAG_NAME ILIKE '%PII%' OR TAG_NAME ILIKE '%PHI%' OR TAG_NAME ILIKE '%PCI%' OR TAG_NAME ILIKE '%CONFIDENTIAL%')
ORDER BY CREATED DESC;

-- ============================================================================
-- Q19: Sensitive-tagged columns missing masking policy (TAG_REFERENCES + POLICY_REFERENCES)
-- ============================================================================
WITH sensitive_cols AS (
  SELECT OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME
  FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
  WHERE (TAG_NAME ILIKE '%PII%' OR TAG_NAME ILIKE '%PHI%' OR TAG_NAME ILIKE '%PCI%' OR TAG_NAME ILIKE '%CONFIDENTIAL%')
),
masked_cols AS (
  SELECT
    REF_DATABASE_NAME AS object_database,
    REF_SCHEMA_NAME   AS object_schema,
    REF_ENTITY_NAME   AS object_name,
    REF_COLUMN_NAME   AS column_name
  FROM SNOWFLAKE.ACCOUNT_USAGE.POLICY_REFERENCES
  WHERE POLICY_KIND = 'MASKING_POLICY'
    AND REF_COLUMN_NAME IS NOT NULL
    AND DELETED_ON IS NULL
)
SELECT
  s.OBJECT_DATABASE,
  s.OBJECT_SCHEMA,
  s.OBJECT_NAME,
  s.COLUMN_NAME
FROM sensitive_cols s
LEFT JOIN masked_cols m
  ON m.object_database = s.OBJECT_DATABASE
 AND m.object_schema   = s.OBJECT_SCHEMA
 AND m.object_name     = s.OBJECT_NAME
 AND m.column_name     = s.COLUMN_NAME
WHERE m.column_name IS NULL
ORDER BY 1,2,3,4;

-- ============================================================================
-- Q20: Sensitive column access (TAG_REFERENCES + ACCESS_HISTORY)
-- Notes: Heavier query. Start with 1–7 days. Good detective control for audits.
-- ============================================================================
WITH tagged AS (
  SELECT OBJECT_DATABASE, OBJECT_SCHEMA, OBJECT_NAME, COLUMN_NAME, TAG_NAME, TAG_VALUE
  FROM SNOWFLAKE.ACCOUNT_USAGE.TAG_REFERENCES
  WHERE (TAG_NAME ILIKE '%PII%' OR TAG_NAME ILIKE '%PHI%' OR TAG_NAME ILIKE '%PCI%' OR TAG_NAME ILIKE '%CONFIDENTIAL%')
),
accessed_cols AS (
  SELECT
    ah.QUERY_ID,
    ah.USER_NAME,
    ah.ROLE_NAME,
    ah.QUERY_START_TIME,
    o.value:"objectName"::STRING AS object_name,
    c.value::STRING AS column_name
  FROM SNOWFLAKE.ACCOUNT_USAGE.ACCESS_HISTORY ah,
       LATERAL FLATTEN(input => ah.BASE_OBJECTS_ACCESSED) o,
       LATERAL FLATTEN(input => o.value:"columns") c
  WHERE ah.QUERY_START_TIME >= DATEADD('day', -7, CURRENT_TIMESTAMP())
)
SELECT
  a.QUERY_START_TIME,
  a.USER_NAME,
  a.ROLE_NAME,
  t.OBJECT_DATABASE,
  t.OBJECT_SCHEMA,
  t.OBJECT_NAME,
  t.COLUMN_NAME,
  t.TAG_NAME,
  t.TAG_VALUE,
  a.QUERY_ID
FROM accessed_cols a
JOIN tagged t
  ON t.OBJECT_NAME     = SPLIT_PART(a.object_name, '.', 3)
 AND t.OBJECT_SCHEMA   = SPLIT_PART(a.object_name, '.', 2)
 AND t.OBJECT_DATABASE = SPLIT_PART(a.object_name, '.', 1)
 AND t.COLUMN_NAME     = a.column_name
ORDER BY a.QUERY_START_TIME DESC;
