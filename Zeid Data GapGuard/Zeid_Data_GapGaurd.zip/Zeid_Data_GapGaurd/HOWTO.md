# HOWTO

Run:
```bash
python gapgaurd.py run --policy policy.sample.json --output ./evidence
```

Verify bundle integrity:
```bash
python gapgaurd.py verify --bundle ./evidence/<bundle_folder>
```
