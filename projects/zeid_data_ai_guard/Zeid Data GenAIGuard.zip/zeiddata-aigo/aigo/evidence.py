from __future__ import annotations

import shutil
import zipfile
from pathlib import Path
from typing import Any, Dict, List, Optional

from .util import dump_json, sha256_file, utc_now_iso, write_text


def build_manifest(root: Path) -> Dict[str, Any]:
    files: List[Dict[str, Any]] = []
    for p in sorted(root.rglob("*")):
        if p.is_dir():
            continue
        rel = p.relative_to(root).as_posix()
        files.append(
            {
                "path": rel,
                "bytes": p.stat().st_size,
                "sha256": sha256_file(p),
            }
        )
    return {
        "manifest_version": "1.0",
        "created_utc": utc_now_iso(),
        "files": files,
    }


def write_narrative(
    root: Path,
    *,
    title: str,
    summary: str,
    contents: Dict[str, str],
) -> None:
    lines = [f"# {title}", "", f"Generated (UTC): {utc_now_iso()}", "", summary, ""]
    lines.append("## Contents")
    for k, v in contents.items():
        lines.append(f"- **{k}**: {v}")
    lines.append("")
    write_text(root / "narrative.md", "\n".join(lines) + "\n")


def make_evidence_bundle(
    *,
    out_dir: Path,
    registry_path: Optional[Path] = None,
    policy_path: Optional[Path] = None,
    eval_report_json: Optional[Path] = None,
    eval_report_html: Optional[Path] = None,
    normalized_events_jsonl: Optional[Path] = None,
    raw_events_jsonl: Optional[Path] = None,
) -> Path:
    """Create a deterministic evidence bundle folder with hash manifest."""
    if out_dir.exists():
        shutil.rmtree(out_dir)
    out_dir.mkdir(parents=True, exist_ok=True)

    contents: Dict[str, str] = {}

    def copy_if(src: Optional[Path], rel: str) -> None:
        if not src:
            return
        dst = out_dir / rel
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst)
        contents[rel] = str(src)

    copy_if(registry_path, "inputs/registry.json")
    copy_if(policy_path, "inputs/policy.json")
    copy_if(eval_report_json, "eval/report.json")
    copy_if(eval_report_html, "eval/report.html")
    copy_if(raw_events_jsonl, "telemetry/raw_events.jsonl")
    copy_if(normalized_events_jsonl, "telemetry/normalized_events.jsonl")

    write_narrative(
        out_dir,
        title="Zeid Data AIGO Evidence Bundle",
        summary=(
            "This bundle contains AI Governance artifacts intended for audit evidence: "
            "inventory, policies, evaluation results, and telemetry exports. "
            "All files are hashed in the manifest to support chain-of-custody."
        ),
        contents=contents,
    )

    manifest = build_manifest(out_dir)
    dump_json(out_dir / "manifest.json", manifest)
    return out_dir


def zip_bundle(bundle_dir: Path, out_zip: Path) -> Path:
    out_zip.parent.mkdir(parents=True, exist_ok=True)
    if out_zip.exists():
        out_zip.unlink()
    with zipfile.ZipFile(out_zip, "w", compression=zipfile.ZIP_DEFLATED) as z:
        for p in sorted(bundle_dir.rglob("*")):
            if p.is_dir():
                continue
            z.write(p, p.relative_to(bundle_dir).as_posix())
    return out_zip
