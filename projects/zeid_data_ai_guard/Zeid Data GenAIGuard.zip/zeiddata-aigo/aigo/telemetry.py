from __future__ import annotations

import uuid
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from .policy import CompiledPolicy, logging_settings, tool_allowlist
from .util import append_jsonl, dump_json, sha256_bytes, utc_now_iso


def _hash_or_store(
    *,
    content: Optional[str],
    store_raw: bool,
    hash_raw: bool,
    raw_dir: Optional[Path],
    prefix: str,
) -> Tuple[Optional[str], Optional[str]]:
    """Return (hash, raw_path_relative) based on settings."""
    if content is None:
        return None, None

    b = content.encode("utf-8", errors="ignore")
    h = sha256_bytes(b) if hash_raw else None

    raw_rel = None
    if store_raw:
        if raw_dir is None:
            raise ValueError("raw_dir must be provided when store_raw is True")
        fname = f"{prefix}-{uuid.uuid4().hex}.txt"
        raw_path = raw_dir / fname
        raw_path.write_text(content, encoding="utf-8")
        raw_rel = fname

    return h, raw_rel


def normalize_event(
    event: Dict[str, Any],
    *,
    compiled_policy: CompiledPolicy,
    raw_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Normalize an input event dict into a stable evidence schema.

    Input is expected to be a JSON object. AIGO does not mandate a vendor format;
    it extracts common fields when present and preserves the original as `source`.
    """
    ls = logging_settings(compiled_policy)
    store_raw = bool(ls.get("store_raw_content", False))
    hash_raw = bool(ls.get("hash_raw_content", True))

    # Common input fields (best-effort)
    prompt = event.get("prompt")
    response = event.get("response")

    prompt_hash, prompt_raw = _hash_or_store(
        content=prompt,
        store_raw=store_raw,
        hash_raw=hash_raw,
        raw_dir=raw_dir,
        prefix="prompt",
    )
    response_hash, response_raw = _hash_or_store(
        content=response,
        store_raw=store_raw,
        hash_raw=hash_raw,
        raw_dir=raw_dir,
        prefix="response",
    )

    # Tool allowlist enforcement
    allow = set(tool_allowlist(compiled_policy))
    tool_calls_in = event.get("tool_calls", [])
    tool_calls: List[Dict[str, Any]] = []
    if isinstance(tool_calls_in, list):
        for tc in tool_calls_in:
            if not isinstance(tc, dict):
                continue
            name = str(tc.get("name", ""))
            allowed = (not allow) or (name in allow)
            tool_calls.append(
                {
                    "name": name,
                    "allowed": allowed,
                    "outcome": tc.get("outcome", ""),
                    "latency_ms": tc.get("latency_ms"),
                }
            )

    normalized: Dict[str, Any] = {
        "event_id": event.get("event_id") or f"evt-{uuid.uuid4().hex[:12]}",
        "ts_utc": event.get("ts_utc") or utc_now_iso(),
        "model_id": event.get("model_id", ""),
        "environment": event.get("environment", ""),
        "actor": event.get("actor", {}),
        "session_id": event.get("session_id", ""),
        "request_id": event.get("request_id", ""),
        "prompt_hash_sha256": prompt_hash,
        "response_hash_sha256": response_hash,
        "raw": {
            "prompt_path": prompt_raw,
            "response_path": response_raw,
        },
        "metrics": {
            "latency_ms": event.get("latency_ms"),
            "tokens_in": event.get("tokens_in"),
            "tokens_out": event.get("tokens_out"),
        },
        "policy": {
            "decision": event.get("policy_decision", ""),
            "rules_hit": event.get("rules_hit", []),
        },
        "tool_calls": tool_calls,
        "error": event.get("error", ""),
        "source": {
            "ingested_from": event.get("ingested_from", ""),
            "original": event,
        },
    }

    return normalized


def normalize_events_jsonl(
    *,
    input_jsonl: Path,
    output_jsonl: Path,
    compiled_policy: CompiledPolicy,
    raw_dir: Optional[Path] = None,
) -> Dict[str, Any]:
    """Normalize events from a JSONL file to a JSONL output."""
    from .util import iter_jsonl

    output_jsonl.parent.mkdir(parents=True, exist_ok=True)
    if raw_dir:
        raw_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    invalid = 0
    for ev in iter_jsonl(input_jsonl):
        try:
            norm = normalize_event(ev, compiled_policy=compiled_policy, raw_dir=raw_dir)
            append_jsonl(output_jsonl, norm)
            count += 1
        except Exception:
            invalid += 1

    summary = {
        "input": str(input_jsonl),
        "output": str(output_jsonl),
        "raw_dir": str(raw_dir) if raw_dir else "",
        "normalized": count,
        "invalid": invalid,
        "ts_utc": utc_now_iso(),
    }
    return summary
