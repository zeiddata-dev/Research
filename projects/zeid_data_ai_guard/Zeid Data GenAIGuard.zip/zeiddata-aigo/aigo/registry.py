from __future__ import annotations

import uuid
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional

from .util import dump_json, load_json, utc_now_iso


@dataclass
class Approval:
    approver: str
    ts_utc: str
    comment: str = ""


@dataclass
class ModelRecord:
    model_id: str
    name: str
    vendor: str
    environment: str
    owner: str
    version: str
    artifact_sha256: str
    endpoint: str = ""
    risk_tier: str = "medium"
    data_classes: List[str] = None  # type: ignore
    tools: List[str] = None  # type: ignore
    approved: bool = False
    approvals: List[Dict[str, Any]] = None  # type: ignore
    created_utc: str = ""


def _defaults() -> Dict[str, Any]:
    return {
        "registry_id": f"reg-{uuid.uuid4().hex}",
        "created_utc": utc_now_iso(),
        "models": [],
    }


def load_registry(path: Path) -> Dict[str, Any]:
    if not path.exists():
        data = _defaults()
        dump_json(path, data)
        return data
    data = load_json(path)
    if not isinstance(data, dict) or "models" not in data:
        raise ValueError("Invalid registry file")
    if not isinstance(data.get("models"), list):
        raise ValueError("registry.models must be a list")
    return data


def save_registry(path: Path, data: Dict[str, Any]) -> None:
    dump_json(path, data)


def add_model(
    reg: Dict[str, Any],
    *,
    name: str,
    vendor: str,
    environment: str,
    owner: str,
    version: str,
    artifact_sha256: str,
    endpoint: str = "",
    risk_tier: str = "medium",
    data_classes: Optional[List[str]] = None,
    tools: Optional[List[str]] = None,
) -> Dict[str, Any]:
    rec: Dict[str, Any] = {
        "model_id": f"m-{uuid.uuid4().hex[:12]}",
        "name": name,
        "vendor": vendor,
        "environment": environment,
        "owner": owner,
        "version": version,
        "artifact_sha256": artifact_sha256,
        "endpoint": endpoint,
        "risk_tier": risk_tier,
        "data_classes": data_classes or [],
        "tools": tools or [],
        "approved": False,
        "approvals": [],
        "created_utc": utc_now_iso(),
    }
    reg["models"].append(rec)
    return rec


def list_models(reg: Dict[str, Any], *, environment: Optional[str] = None) -> List[Dict[str, Any]]:
    models = reg.get("models", [])
    if environment:
        return [m for m in models if m.get("environment") == environment]
    return list(models)


def find_model(reg: Dict[str, Any], model_id: str) -> Dict[str, Any]:
    for m in reg.get("models", []):
        if m.get("model_id") == model_id:
            return m
    raise KeyError(f"Model not found: {model_id}")


def approve_model(reg: Dict[str, Any], model_id: str, approver: str, comment: str = "") -> Dict[str, Any]:
    m = find_model(reg, model_id)
    m.setdefault("approvals", []).append(
        {"approver": approver, "ts_utc": utc_now_iso(), "comment": comment}
    )
    m["approved"] = True
    return m
