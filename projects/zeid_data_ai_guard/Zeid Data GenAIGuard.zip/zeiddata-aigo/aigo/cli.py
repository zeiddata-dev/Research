from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Any, Dict, Optional

from . import __version__
from .evidence import make_evidence_bundle, zip_bundle
from .evals import run_eval_suite
from .html_report import write_eval_report_html
from .policy import compile_policy, load_policy
from .registry import add_model, approve_model, load_registry, list_models, save_registry
from .telemetry import normalize_events_jsonl
from .util import dump_json, utc_now_iso, write_text


def _workspace_path(workspace: Path, name: str) -> Path:
    return workspace / name


def cmd_init(args: argparse.Namespace) -> int:
    ws = Path(args.workspace).resolve()
    ws.mkdir(parents=True, exist_ok=True)

    reg_path = _workspace_path(ws, "registry.json")
    load_registry(reg_path)  # creates if missing

    policy_path = _workspace_path(ws, "policy.json")
    if not policy_path.exists():
        sample_policy = Path(__file__).resolve().parent.parent / "sample_data" / "policy.json"
        policy_path.write_text(sample_policy.read_text(encoding="utf-8"), encoding="utf-8")

    (ws / "out").mkdir(exist_ok=True)
    (ws / "evidence").mkdir(exist_ok=True)

    print(f"Initialized AIGO workspace: {ws}")
    print(f"- registry: {reg_path}")
    print(f"- policy:   {policy_path}")
    return 0


def cmd_model_add(args: argparse.Namespace) -> int:
    reg_path = Path(args.registry).resolve()
    reg = load_registry(reg_path)
    rec = add_model(
        reg,
        name=args.name,
        vendor=args.vendor,
        environment=args.environment,
        owner=args.owner,
        version=args.version,
        artifact_sha256=args.artifact_sha256,
        endpoint=args.endpoint or "",
        risk_tier=args.risk_tier,
        data_classes=args.data_classes or [],
        tools=args.tools or [],
    )
    save_registry(reg_path, reg)
    print(f"Added model: {rec['model_id']} ({rec['name']})")
    return 0


def cmd_model_list(args: argparse.Namespace) -> int:
    reg = load_registry(Path(args.registry).resolve())
    models = list_models(reg, environment=args.environment)
    if args.json:
        dump_json(Path(args.json).resolve(), models)
        print(f"Wrote: {args.json}")
        return 0

    if not models:
        print("No models in registry.")
        return 0

    for m in models:
        print(
            f"{m.get('model_id')}\t{m.get('environment')}\t{m.get('approved')}\t{m.get('vendor')}\t{m.get('name')}\t{m.get('version')}"
        )
    return 0


def cmd_model_approve(args: argparse.Namespace) -> int:
    reg_path = Path(args.registry).resolve()
    reg = load_registry(reg_path)
    m = approve_model(reg, args.model_id, args.approver, comment=args.comment or "")
    save_registry(reg_path, reg)
    print(f"Approved model: {m.get('model_id')} by {args.approver}")
    return 0


def cmd_eval_run(args: argparse.Namespace) -> int:
    policy = compile_policy(load_policy(Path(args.policy).resolve()))
    out_json = Path(args.out_json).resolve()

    report = run_eval_suite(
        suite_jsonl=Path(args.suite).resolve(),
        output_json=out_json,
        compiled_policy=policy,
        model_id=args.model_id or "",
        context={"run_by": args.run_by or "", "ts_utc": utc_now_iso()},
    )
    print(f"Wrote eval report: {out_json}")

    if args.out_html:
        out_html = Path(args.out_html).resolve()
        write_eval_report_html(report, out_html)
        print(f"Wrote eval HTML: {out_html}")

    # Exit code should fail CI if gates fail
    return 0 if report.get("gate_summary", {}).get("pass") else 2


def cmd_telemetry_normalize(args: argparse.Namespace) -> int:
    policy = compile_policy(load_policy(Path(args.policy).resolve()))
    raw_dir = Path(args.raw_dir).resolve() if args.raw_dir else None

    summary = normalize_events_jsonl(
        input_jsonl=Path(args.input).resolve(),
        output_jsonl=Path(args.output).resolve(),
        compiled_policy=policy,
        raw_dir=raw_dir,
    )
    if args.summary_json:
        dump_json(Path(args.summary_json).resolve(), summary)
        print(f"Wrote summary: {args.summary_json}")
    print(f"Normalized events: {summary['normalized']} (invalid: {summary['invalid']})")
    return 0


def cmd_evidence_pack(args: argparse.Namespace) -> int:
    bundle_dir = make_evidence_bundle(
        out_dir=Path(args.out_dir).resolve(),
        registry_path=Path(args.registry).resolve() if args.registry else None,
        policy_path=Path(args.policy).resolve() if args.policy else None,
        eval_report_json=Path(args.eval_json).resolve() if args.eval_json else None,
        eval_report_html=Path(args.eval_html).resolve() if args.eval_html else None,
        raw_events_jsonl=Path(args.raw_events).resolve() if args.raw_events else None,
        normalized_events_jsonl=Path(args.norm_events).resolve() if args.norm_events else None,
    )
    print(f"Created bundle: {bundle_dir}")

    if args.zip:
        out_zip = zip_bundle(bundle_dir, Path(args.zip).resolve())
        print(f"Created zip: {out_zip}")

    return 0


def cmd_schema(args: argparse.Namespace) -> int:
    schema = {
        "normalized_event": {
            "event_id": "evt-...",
            "ts_utc": "2026-01-17T12:34:56Z",
            "model_id": "m-...",
            "environment": "prod|stage|dev",
            "actor": {"user_id": "...", "roles": ["..."]},
            "session_id": "...",
            "request_id": "...",
            "prompt_hash_sha256": "...",
            "response_hash_sha256": "...",
            "raw": {"prompt_path": "prompt-...txt", "response_path": "response-...txt"},
            "metrics": {"latency_ms": 123, "tokens_in": 1, "tokens_out": 1},
            "policy": {"decision": "allow|deny", "rules_hit": ["..."]},
            "tool_calls": [{"name": "tool.name", "allowed": True, "outcome": "ok", "latency_ms": 10}],
            "error": "",
            "source": {"ingested_from": "app|proxy|gateway", "original": {"...": "..."}},
        }
    }
    if args.out:
        dump_json(Path(args.out).resolve(), schema)
        print(f"Wrote schema: {args.out}")
    else:
        import json

        print(json.dumps(schema, indent=2, sort_keys=True))
    return 0


def build_parser() -> argparse.ArgumentParser:
    p = argparse.ArgumentParser(prog="aigo", description="Zeid Data AI Governance Evidence Toolkit")
    p.add_argument("--version", action="version", version=f"aigo {__version__}")

    sub = p.add_subparsers(dest="cmd", required=True)

    sp = sub.add_parser("init", help="Initialize a workspace (registry + sample policy)")
    sp.add_argument("--workspace", default=".", help="Workspace directory")
    sp.set_defaults(func=cmd_init)

    m = sub.add_parser("model", help="Manage model registry")
    msub = m.add_subparsers(dest="subcmd", required=True)

    madd = msub.add_parser("add", help="Add a model record")
    madd.add_argument("--registry", default="registry.json")
    madd.add_argument("--name", required=True)
    madd.add_argument("--vendor", default="")
    madd.add_argument("--environment", default="prod")
    madd.add_argument("--owner", default="")
    madd.add_argument("--version", required=True)
    madd.add_argument("--artifact-sha256", required=True)
    madd.add_argument("--endpoint", default="")
    madd.add_argument("--risk-tier", default="medium", choices=["low", "medium", "high"])
    madd.add_argument("--data-classes", nargs="*", default=[])
    madd.add_argument("--tools", nargs="*", default=[])
    madd.set_defaults(func=cmd_model_add)

    mlist = msub.add_parser("list", help="List models")
    mlist.add_argument("--registry", default="registry.json")
    mlist.add_argument("--environment", default=None)
    mlist.add_argument("--json", default="", help="Write output JSON to this path")
    mlist.set_defaults(func=cmd_model_list)

    mappr = msub.add_parser("approve", help="Approve a model")
    mappr.add_argument("--registry", default="registry.json")
    mappr.add_argument("model_id")
    mappr.add_argument("--approver", required=True)
    mappr.add_argument("--comment", default="")
    mappr.set_defaults(func=cmd_model_approve)

    e = sub.add_parser("eval", help="Run evaluation suite gates")
    esub = e.add_subparsers(dest="subcmd", required=True)

    erun = esub.add_parser("run", help="Run a JSONL eval suite (prompt+response pairs)")
    erun.add_argument("--suite", required=True, help="JSONL file of {prompt,response,...}")
    erun.add_argument("--policy", default="policy.json")
    erun.add_argument("--model-id", default="")
    erun.add_argument("--run-by", default="")
    erun.add_argument("--out-json", required=True)
    erun.add_argument("--out-html", default="")
    erun.set_defaults(func=cmd_eval_run)

    t = sub.add_parser("telemetry", help="Normalize telemetry/events")
    tsub = t.add_subparsers(dest="subcmd", required=True)

    tnorm = tsub.add_parser("normalize", help="Normalize events JSONL into evidence schema")
    tnorm.add_argument("--input", required=True)
    tnorm.add_argument("--output", required=True)
    tnorm.add_argument("--policy", default="policy.json")
    tnorm.add_argument("--raw-dir", default="", help="If store_raw_content enabled, write raw prompt/response here")
    tnorm.add_argument("--summary-json", default="", help="Write normalization summary JSON")
    tnorm.set_defaults(func=cmd_telemetry_normalize)

    ev = sub.add_parser("evidence", help="Create evidence bundles and audit packs")
    evsub = ev.add_subparsers(dest="subcmd", required=True)

    pack = evsub.add_parser("pack", help="Create evidence bundle folder and optional zip")
    pack.add_argument("--out-dir", required=True)
    pack.add_argument("--zip", default="")
    pack.add_argument("--registry", default="")
    pack.add_argument("--policy", default="")
    pack.add_argument("--eval-json", default="")
    pack.add_argument("--eval-html", default="")
    pack.add_argument("--raw-events", default="")
    pack.add_argument("--norm-events", default="")
    pack.set_defaults(func=cmd_evidence_pack)

    sc = sub.add_parser("schema", help="Print or write example schemas")
    sc.add_argument("--out", default="")
    sc.set_defaults(func=cmd_schema)

    return p


def main(argv: Optional[list[str]] = None) -> int:
    parser = build_parser()
    args = parser.parse_args(argv)
    return int(args.func(args))


if __name__ == "__main__":
    raise SystemExit(main())
