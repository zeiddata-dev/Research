"""Zeid Data - AI Governance Evidence Toolkit (AIGO).

AIGO is a lightweight, audit-evidence-first CLI to:
- Maintain a model/system inventory ("model registry")
- Run evaluation gates (policy + regression suites)
- Normalize AI telemetry into an evidence-friendly schema
- Produce evidence bundles (hash manifests) and an "audit pack" zip

The outputs are designed to be reproducible and audit-friendly.
"""

__all__ = ["__version__"]

__version__ = "0.1.0"
