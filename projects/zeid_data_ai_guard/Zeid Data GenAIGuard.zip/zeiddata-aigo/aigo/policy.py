from __future__ import annotations

import re
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Pattern, Tuple

from .util import load_json


@dataclass(frozen=True)
class CompiledPolicy:
    raw: Dict[str, Any]
    sensitive_patterns: Dict[str, List[Pattern[str]]]


def load_policy(path: Path) -> Dict[str, Any]:
    """Load a policy file.

    The default format is JSON. If you want YAML, install PyYAML and convert
    externally, or extend this loader.
    """
    if path.suffix.lower() not in {".json", ".policy"}:
        raise ValueError(
            f"Unsupported policy format: {path.suffix}. Use JSON (.json)."
        )
    data = load_json(path)
    if not isinstance(data, dict):
        raise ValueError("Policy must be a JSON object")
    return data


def _compile_pattern_list(patterns: List[str]) -> List[Pattern[str]]:
    compiled: List[Pattern[str]] = []
    for p in patterns:
        compiled.append(re.compile(p, re.IGNORECASE))
    return compiled


def compile_policy(policy: Dict[str, Any]) -> CompiledPolicy:
    sp = policy.get("sensitive_patterns", {})
    if not isinstance(sp, dict):
        raise ValueError("policy.sensitive_patterns must be an object")

    compiled: Dict[str, List[Pattern[str]]] = {}
    for severity, pats in sp.items():
        if not isinstance(pats, list) or not all(isinstance(x, str) for x in pats):
            raise ValueError(
                f"policy.sensitive_patterns.{severity} must be a list of strings"
            )
        compiled[severity] = _compile_pattern_list(pats)

    return CompiledPolicy(raw=policy, sensitive_patterns=compiled)


def find_sensitive_hits(text: str, compiled: CompiledPolicy) -> List[Tuple[str, str]]:
    """Return a list of (severity, pattern) matches found in text."""
    hits: List[Tuple[str, str]] = []
    for severity, pats in compiled.sensitive_patterns.items():
        for p in pats:
            if p.search(text):
                hits.append((severity, p.pattern))
    return hits


def citation_required(compiled: CompiledPolicy) -> bool:
    return bool(compiled.raw.get("citation_required", False))


def tool_allowlist(compiled: CompiledPolicy) -> List[str]:
    allow = compiled.raw.get("tool_allowlist", [])
    if isinstance(allow, list) and all(isinstance(x, str) for x in allow):
        return allow
    return []


def logging_settings(compiled: CompiledPolicy) -> Dict[str, Any]:
    ls = compiled.raw.get("logging", {})
    return ls if isinstance(ls, dict) else {}


def eval_gates(compiled: CompiledPolicy) -> Dict[str, Any]:
    eg = compiled.raw.get("eval_gates", {})
    return eg if isinstance(eg, dict) else {}
