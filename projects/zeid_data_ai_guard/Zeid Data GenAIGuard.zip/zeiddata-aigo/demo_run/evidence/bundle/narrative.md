# Zeid Data AIGO Evidence Bundle

Generated (UTC): 2026-01-17T10:03:52Z

This bundle contains AI Governance artifacts intended for audit evidence: inventory, policies, evaluation results, and telemetry exports. All files are hashed in the manifest to support chain-of-custody.

## Contents
- **inputs/registry.json**: /mnt/data/zeiddata-aigo/demo_run/registry.json
- **inputs/policy.json**: /mnt/data/zeiddata-aigo/demo_run/policy.json
- **eval/report.json**: /mnt/data/zeiddata-aigo/demo_run/out/eval_report.json
- **eval/report.html**: /mnt/data/zeiddata-aigo/demo_run/out/eval_report.html
- **telemetry/raw_events.jsonl**: /mnt/data/zeiddata-aigo/sample_data/events.jsonl
- **telemetry/normalized_events.jsonl**: /mnt/data/zeiddata-aigo/demo_run/out/normalized_events.jsonl

