#!/usr/bin/env bash
set -euo pipefail
python -m unittest discover -s tests -t .
