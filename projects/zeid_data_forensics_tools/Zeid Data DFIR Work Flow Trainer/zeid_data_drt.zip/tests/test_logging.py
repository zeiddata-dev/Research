import unittest
from pathlib import Path
import tempfile

from zd_drt.logging import append_coc, verify_coc_hash_chain

class TestLogging(unittest.TestCase):
    def test_hash_chain(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "coc.jsonl"
            append_coc(p, "a", "x", {"k": 1})
            append_coc(p, "a", "y", {"k": 2})
            ok, issues = verify_coc_hash_chain(p)
            self.assertTrue(ok)
            self.assertEqual(issues, [])

if __name__ == "__main__":
    unittest.main()
