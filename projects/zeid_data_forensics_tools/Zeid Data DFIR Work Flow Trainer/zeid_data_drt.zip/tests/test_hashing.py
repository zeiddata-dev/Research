import unittest
from pathlib import Path
import tempfile

from zd_drt.core import sha256_file

class TestHashing(unittest.TestCase):
    def test_sha256_file(self):
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "a.txt"
            p.write_text("hello", encoding="utf-8")
            h = sha256_file(p)
            self.assertEqual(len(h), 64)
            # stable known hash for "hello"
            self.assertEqual(h, "2cf24dba5fb0a30e26e83b2ac5b9e29e1b161e5c1fa7425e73043362938b9824")

if __name__ == "__main__":
    unittest.main()
