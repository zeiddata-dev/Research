import unittest
from pathlib import Path
import tempfile
import json

from zd_drt.reporting import render_markdown

class TestReport(unittest.TestCase):
    def test_render_markdown(self):
        md = render_markdown(
            case_meta={"case_id": "X"},
            evidence_manifest=None,
            verify_summary={"ok": True},
            sim_summary={"containers": []},
            coc_entries=[],
            coc_ok=True,
            coc_issues=[]
        )
        self.assertIn("# Zeid Data — DRT Report", md)
        self.assertIn("Case metadata", md)

if __name__ == "__main__":
    unittest.main()
