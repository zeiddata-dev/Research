import unittest
from pathlib import Path
import tempfile
import json

from zd_drt.core import build_manifest, write_manifest_json, load_manifest_json

class TestManifest(unittest.TestCase):
    def test_manifest_roundtrip(self):
        with tempfile.TemporaryDirectory() as td:
            root = Path(td) / "root"
            root.mkdir()
            (root / "a.txt").write_text("a", encoding="utf-8")
            (root / "b.txt").write_text("b", encoding="utf-8")

            recs = build_manifest(root)
            self.assertEqual(len(recs), 2)

            out = Path(td) / "manifest.json"
            write_manifest_json(out, recs, extra={"test": True})
            man = load_manifest_json(out)
            self.assertIn("manifest_sha256", man)
            self.assertEqual(man["file_count"], 2)
            self.assertTrue(man.get("test"))

if __name__ == "__main__":
    unittest.main()
