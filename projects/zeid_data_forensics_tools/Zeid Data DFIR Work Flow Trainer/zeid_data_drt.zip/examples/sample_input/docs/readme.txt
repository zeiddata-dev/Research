This is a sample training document. No sensitive data.
