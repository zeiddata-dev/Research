from __future__ import annotations

import csv
import hashlib
import json
import os
import shutil
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Tuple

from .utils import ensure_dir, now_utc_iso, relpath_under

CHUNK = 8 * 1024 * 1024  # 8 MiB

@dataclass(frozen=True)
class FileRecord:
    path: str          # relative path (forward slashes)
    size: int
    mtime_utc: str
    sha256: str

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        while True:
            b = f.read(CHUNK)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def sha256_bytes_iter(chunks: Iterable[bytes]) -> str:
    h = hashlib.sha256()
    for c in chunks:
        h.update(c)
    return h.hexdigest()

def list_files(root: Path) -> list[Path]:
    files: list[Path] = []
    for p in root.rglob("*"):
        if p.is_file():
            files.append(p)
    return sorted(files)

def build_manifest(root: Path) -> list[FileRecord]:
    records: list[FileRecord] = []
    for p in list_files(root):
        st = p.stat()
        mtime = now_utc_iso()  # keep simple; training-grade
        records.append(
            FileRecord(
                path=relpath_under(root, p),
                size=int(st.st_size),
                mtime_utc=mtime,
                sha256=sha256_file(p),
            )
        )
    return records

def write_manifest_json(path: Path, records: list[FileRecord], extra: Optional[dict[str, Any]] = None) -> None:
    ensure_dir(path.parent)
    payload = {
        "generated_utc": now_utc_iso(),
        "file_count": len(records),
        "files": [r.__dict__ for r in records],
    }
    if extra:
        payload.update(extra)
    # manifest digest (excluding itself)
    raw = json.dumps(payload, sort_keys=True).encode("utf-8")
    payload["manifest_sha256"] = hashlib.sha256(raw).hexdigest()
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")

def write_manifest_csv(path: Path, records: list[FileRecord]) -> None:
    ensure_dir(path.parent)
    with path.open("w", newline="", encoding="utf-8") as f:
        w = csv.writer(f)
        w.writerow(["path", "size", "mtime_utc", "sha256"])
        for r in records:
            w.writerow([r.path, r.size, r.mtime_utc, r.sha256])

def copy_tree(src: Path, dst: Path) -> None:
    ensure_dir(dst)
    for p in src.rglob("*"):
        rel = p.relative_to(src)
        out = dst / rel
        if p.is_dir():
            ensure_dir(out)
        elif p.is_file():
            ensure_dir(out.parent)
            shutil.copy2(p, out)

def set_readonly_tree(root: Path) -> None:
    """
    Best-effort readonly simulation.
    On Windows, permissions may be limited; we still attempt.
    """
    for p in root.rglob("*"):
        try:
            if p.is_dir():
                # r-xr-xr-x
                p.chmod(0o555)
            elif p.is_file():
                # r--r--r--
                p.chmod(0o444)
        except Exception:
            # Ignore permission errors for training portability
            pass

def load_manifest_json(path: Path) -> dict[str, Any]:
    return json.loads(path.read_text(encoding="utf-8"))

def verify_against_manifest(root: Path, manifest: dict[str, Any]) -> tuple[bool, list[dict[str, Any]]]:
    """
    Recompute sha256 of files in `root` and compare against manifest files list.
    Returns (ok, mismatches)
    """
    expected = {f["path"]: f for f in manifest.get("files", [])}
    mismatches: list[dict[str, Any]] = []

    # Check missing / changed
    for rel_path, fmeta in expected.items():
        target = root / Path(rel_path)
        if not target.exists():
            mismatches.append({"path": rel_path, "issue": "missing"})
            continue
        if not target.is_file():
            mismatches.append({"path": rel_path, "issue": "not_a_file"})
            continue
        actual = sha256_file(target)
        if actual != fmeta.get("sha256"):
            mismatches.append({"path": rel_path, "issue": "sha256_mismatch", "expected": fmeta.get("sha256"), "actual": actual})

    # Check unexpected new files
    for p in list_files(root):
        rel = relpath_under(root, p)
        if rel not in expected:
            mismatches.append({"path": rel, "issue": "unexpected_file"})

    return (len(mismatches) == 0), mismatches
