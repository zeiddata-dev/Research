from __future__ import annotations

import hashlib
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .utils import ensure_dir, now_utc_iso

@dataclass(frozen=True)
class CocEntry:
    timestamp_utc: str
    analyst: str
    action: str
    details: dict[str, Any]
    prev_hash: str
    entry_hash: str

def _hash_entry(prev_hash: str, timestamp: str, analyst: str, action: str, details: dict[str, Any]) -> str:
    blob = json.dumps(
        {
            "prev_hash": prev_hash,
            "timestamp_utc": timestamp,
            "analyst": analyst,
            "action": action,
            "details": details,
        },
        sort_keys=True,
    ).encode("utf-8")
    return hashlib.sha256(blob).hexdigest()

def read_last_hash(log_path: Path) -> str:
    if not log_path.exists():
        return "0" * 64
    last = None
    with log_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                last = line
    if not last:
        return "0" * 64
    try:
        obj = json.loads(last)
        return obj.get("entry_hash", "0" * 64)
    except Exception:
        return "0" * 64

def append_coc(log_path: Path, analyst: str, action: str, details: dict[str, Any]) -> CocEntry:
    ensure_dir(log_path.parent)
    ts = now_utc_iso()
    prev = read_last_hash(log_path)
    eh = _hash_entry(prev, ts, analyst, action, details)
    entry = CocEntry(ts, analyst, action, details, prev, eh)
    with log_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(entry.__dict__, sort_keys=True) + "\n")
    return entry

def load_coc(log_path: Path) -> list[dict[str, Any]]:
    if not log_path.exists():
        return []
    out: list[dict[str, Any]] = []
    with log_path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                out.append(json.loads(line))
            except Exception:
                # skip malformed lines (training-friendly)
                continue
    return out

def verify_coc_hash_chain(log_path: Path) -> tuple[bool, list[str]]:
    """
    Verifies the tamper-evident hash chain.
    Returns (ok, issues)
    """
    issues: list[str] = []
    entries = load_coc(log_path)
    prev = "0" * 64
    for i, e in enumerate(entries):
        expected = _hash_entry(prev, e["timestamp_utc"], e["analyst"], e["action"], e["details"])
        if e.get("prev_hash") != prev:
            issues.append(f"Entry {i}: prev_hash mismatch")
        if e.get("entry_hash") != expected:
            issues.append(f"Entry {i}: entry_hash mismatch")
        prev = e.get("entry_hash", prev)
    return (len(issues) == 0), issues
