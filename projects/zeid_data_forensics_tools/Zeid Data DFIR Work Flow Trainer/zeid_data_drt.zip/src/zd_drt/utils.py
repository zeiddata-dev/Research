from __future__ import annotations

import os
import re
from pathlib import Path
from typing import Iterable

BANNER = "Authorized training use only. Do not use on systems or data you do not own or have explicit permission to analyze."

# Block-device style patterns (best-effort guardrails)
_BANNED_SUBSTRINGS = [
    "/dev/",
    "\\\\.\\physicaldrive",   # Windows
    "physicaldrive",
    "disk0",
    "rdisk",
]

def now_utc_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")

def ensure_dir(path: Path) -> None:
    path.mkdir(parents=True, exist_ok=True)

def assert_safe_path(user_path: str) -> None:
    """
    Reject paths that resemble raw block devices or system disk identifiers.
    This is a guardrail, not a security boundary.
    """
    p = user_path.strip()
    if not p:
        raise ValueError("Path is empty.")

    lower = p.lower()
    for bad in _BANNED_SUBSTRINGS:
        if bad in lower:
            raise ValueError(
                f"Unsafe path rejected: '{user_path}'. "
                "DRT does not read raw block devices or system disks."
            )

    # Also reject Windows device namespace patterns like \\.\
    if lower.startswith("\\\\.\\") or lower.startswith("\\\\?\\"):
        raise ValueError(
            f"Unsafe device namespace rejected: '{user_path}'. "
            "DRT only accepts normal folders and DRT-created containers."
        )

def relpath_under(root: Path, child: Path) -> str:
    return str(child.relative_to(root)).replace("\\", "/")

def match_globs(paths: Iterable[str], patterns: list[str]) -> list[str]:
    """
    Simple glob matching on forward-slashed relative paths.
    Supports '*' and '**' semantics via fnmatch-like translation.
    """
    import fnmatch
    selected: list[str] = []
    for p in paths:
        for pat in patterns:
            if fnmatch.fnmatch(p, pat):
                selected.append(p)
                break
    return sorted(set(selected))
