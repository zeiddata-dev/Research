from __future__ import annotations

import argparse
import json
import os
import shutil
from pathlib import Path
from typing import Any, Optional

from .utils import BANNER, ensure_dir, now_utc_iso, assert_safe_path, match_globs
from .core import copy_tree, set_readonly_tree, build_manifest, write_manifest_json, write_manifest_csv, load_manifest_json, verify_against_manifest, sha256_file
from .logging import append_coc
from .image import generate_synthetic_dataset, create_training_image, list_container_files, ensure_sim_state, simulate_delete as simdel, restore_simulated as simres, extract_from_container
from .reporting import render_markdown, write_report_md, write_report_pdf, coc_status

TOOL_NAME = "Zeid Data DRT"
VERSION = "0.1.0"

def banner() -> str:
    return f"{TOOL_NAME} v{VERSION}\n{BANNER}\n"

def case_dir(cases_dir: Path, case_id: str) -> Path:
    return cases_dir / case_id

def case_meta_path(cases_dir: Path, case_id: str) -> Path:
    return case_dir(cases_dir, case_id) / "case.json"

def load_case_meta(cases_dir: Path, case_id: str) -> dict[str, Any]:
    p = case_meta_path(cases_dir, case_id)
    if not p.exists():
        raise FileNotFoundError(f"Case not found: {p}")
    return json.loads(p.read_text(encoding="utf-8"))

def init_case(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    ensure_dir(cases_dir)
    cdir = case_dir(cases_dir, args.case_id)
    ensure_dir(cdir)

    for sub in ["evidence", "working", "exports", "reports", "logs"]:
        ensure_dir(cdir / sub)

    meta = {
        "case_id": args.case_id,
        "analyst": args.analyst,
        "authorization": args.auth,
        "created_utc": now_utc_iso(),
        "tool": {"name": TOOL_NAME, "version": VERSION},
    }
    case_meta_path(cases_dir, args.case_id).write_text(json.dumps(meta, indent=2), encoding="utf-8")

    coc_path = cdir / "logs" / "chain_of_custody.jsonl"
    append_coc(coc_path, args.analyst, "init_case", {"case_id": args.case_id})

    print(banner())
    print(f"Case initialized: {cdir}")

def ingest(args: argparse.Namespace) -> None:
    assert_safe_path(args.input)
    src = Path(args.input).resolve()
    if not src.exists() or not src.is_dir():
        raise ValueError("Input must be a folder of training files.")

    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    if not cdir.exists():
        raise FileNotFoundError(f"Case directory not found: {cdir}")

    analyst = args.analyst or load_case_meta(cases_dir, args.case_id).get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    evidence_dir = cdir / "evidence"
    # ingest into evidence/ingested_<timestamp> to preserve multiple ingests
    stamp = now_utc_iso().replace(":", "").replace("-", "")
    ingest_root = evidence_dir / f"ingested_{stamp}"
    ensure_dir(ingest_root)

    append_coc(coc_path, analyst, "ingest_start", {"input": str(src)})

    copy_tree(src, ingest_root)
    set_readonly_tree(ingest_root)

    records = build_manifest(ingest_root)
    man_json = cdir / "evidence" / "manifest.json"
    man_csv = cdir / "evidence" / "manifest.csv"
    write_manifest_json(man_json, records, extra={"ingest_root": str(ingest_root)})
    write_manifest_csv(man_csv, records)

    append_coc(coc_path, analyst, "ingest_complete", {"file_count": len(records), "manifest_json": str(man_json), "manifest_csv": str(man_csv)})
    print(banner())
    print(f"Ingested training folder into: {ingest_root}")
    print(f"Manifest written: {man_json} and {man_csv}")

def make_image(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    if not cdir.exists():
        raise FileNotFoundError(f"Case not found: {cdir}")

    analyst = args.analyst or load_case_meta(cases_dir, args.case_id).get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    # Create dataset in working/synthetic_dataset_<timestamp>
    stamp = now_utc_iso().replace(":", "").replace("-", "")
    dataset_root = cdir / "working" / f"synthetic_dataset_{stamp}"
    ensure_dir(dataset_root)
    generate_synthetic_dataset(dataset_root)

    # Create container at exports/training_image.tar.gz (stable name) unless override
    container_name = args.output_name or "training_image.tar.gz"
    container_path = cdir / "exports" / container_name

    append_coc(coc_path, analyst, "make_image_start", {"dataset_root": str(dataset_root), "container": str(container_path)})
    meta = create_training_image(container_path, dataset_root)
    append_coc(coc_path, analyst, "make_image_complete", meta)

    # Initialize sim state for this container
    sim_dir = cdir / "working" / "simulations" / container_name.replace(".tar.gz", "")
    files = list_container_files(container_path)
    ensure_sim_state(sim_dir, files)

    print(banner())
    print(f"Synthetic training image created: {container_path}")
    print(f"Container SHA-256: {meta['container_sha256']}")
    print(f"Simulation state initialized: {sim_dir}")

def simulate_delete(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    analyst = args.analyst or load_case_meta(cases_dir, args.case_id).get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    container_name = args.image_name
    container_path = cdir / "exports" / container_name
    if not container_path.exists():
        raise FileNotFoundError(f"Container not found: {container_path}")

    patterns = args.match or []
    if not patterns:
        raise ValueError("Provide at least one --match pattern (e.g., 'docs/*').")

    sim_dir = cdir / "working" / "simulations" / container_name.replace(".tar.gz", "")
    active = sim_dir / "active_manifest.json"
    history = sim_dir / "history.jsonl"

    if not active.exists():
        files = list_container_files(container_path)
        ensure_sim_state(sim_dir, files)

    result = simdel(active, history, patterns, actor=analyst)
    append_coc(coc_path, analyst, "simulate_delete", {"container": container_name, "patterns": patterns, "deleted_count": len(result.get("deleted", []))})

    print(banner())
    print(result["message"])
    for f in result.get("deleted", []):
        print(f" - {f}")

def restore_simulated(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    analyst = args.analyst or load_case_meta(cases_dir, args.case_id).get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    container_name = args.image_name
    container_path = cdir / "exports" / container_name
    if not container_path.exists():
        raise FileNotFoundError(f"Container not found: {container_path}")

    patterns = args.match or []
    if not patterns:
        raise ValueError("Provide at least one --match pattern (e.g., 'docs/*').")

    sim_dir = cdir / "working" / "simulations" / container_name.replace(".tar.gz", "")
    active = sim_dir / "active_manifest.json"
    history = sim_dir / "history.jsonl"
    if not active.exists():
        files = list_container_files(container_path)
        ensure_sim_state(sim_dir, files)

    # First restore in metadata
    result = simres(active, history, patterns, actor=analyst)

    # Then extract restored files to working/restored/<container>/
    restored = result.get("restored", [])
    out_dir = cdir / "working" / "restored" / container_name.replace(".tar.gz", "")
    extracted = extract_from_container(container_path, restored, out_dir) if restored else []

    append_coc(coc_path, analyst, "restore_simulated", {"container": container_name, "patterns": patterns, "restored_count": len(restored), "extracted_count": len(extracted)})

    print(banner())
    print(result["message"])
    if extracted:
        print(f"Extracted to: {out_dir}")
        for f in extracted:
            print(f" - {f}")

def verify(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    analyst = args.analyst or load_case_meta(cases_dir, args.case_id).get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    summary: dict[str, Any] = {"verified_utc": now_utc_iso(), "evidence": None, "container": []}

    # Evidence verify (if manifest exists)
    man_json = cdir / "evidence" / "manifest.json"
    if man_json.exists():
        manifest = load_manifest_json(man_json)
        ingest_root = manifest.get("ingest_root")
        if ingest_root:
            root = Path(ingest_root)
            ok, mismatches = verify_against_manifest(root, manifest)
            summary["evidence"] = {"ok": ok, "mismatches": mismatches, "ingest_root": ingest_root}
        else:
            summary["evidence"] = {"ok": False, "mismatches": [{"issue": "manifest_missing_ingest_root"}]}

    # Container verify: verify container SHA-256 if present in logs (best-effort)
    # Also verify that tar contains expected manifest file entry (if present).
    exports_dir = cdir / "exports"
    for p in exports_dir.glob("*.tar.gz"):
        container_sha = sha256_file(p)
        summary["container"].append({"name": p.name, "sha256": container_sha})

    append_coc(coc_path, analyst, "verify", {"summary": summary})
    print(banner())
    print(json.dumps(summary, indent=2))

def report(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    meta = load_case_meta(cases_dir, args.case_id)
    analyst = args.analyst or meta.get("analyst", "unknown")
    coc_path = cdir / "logs" / "chain_of_custody.jsonl"

    # Evidence manifest if present
    evidence_manifest = None
    man_json = cdir / "evidence" / "manifest.json"
    if man_json.exists():
        evidence_manifest = json.loads(man_json.read_text(encoding="utf-8"))

    # Verification summary (reuse verify logic but in-memory)
    verify_summary: dict[str, Any] = {"generated_utc": now_utc_iso(), "evidence": None, "container": []}
    if evidence_manifest and evidence_manifest.get("ingest_root"):
        root = Path(evidence_manifest["ingest_root"])
        ok, mismatches = verify_against_manifest(root, evidence_manifest)
        verify_summary["evidence"] = {"ok": ok, "mismatches": mismatches, "ingest_root": str(root)}

    exports_dir = cdir / "exports"
    for p in exports_dir.glob("*.tar.gz"):
        verify_summary["container"].append({"name": p.name, "sha256": sha256_file(p)})

    # Simulation summary (best-effort scan)
    sim_summary: dict[str, Any] = {"generated_utc": now_utc_iso(), "containers": []}
    sim_root = cdir / "working" / "simulations"
    if sim_root.exists():
        for sdir in sorted([d for d in sim_root.iterdir() if d.is_dir()]):
            active = sdir / "active_manifest.json"
            hist = sdir / "history.jsonl"
            entry = {"name": sdir.name, "active_manifest": None, "history_events": 0}
            if active.exists():
                entry["active_manifest"] = json.loads(active.read_text(encoding="utf-8"))
            if hist.exists():
                entry["history_events"] = sum(1 for _ in hist.open("r", encoding="utf-8") if _.strip())
            sim_summary["containers"].append(entry)

    coc_entries, coc_ok, coc_issues = coc_status(coc_path)

    md = render_markdown(meta, evidence_manifest, verify_summary, sim_summary, coc_entries, coc_ok, coc_issues)

    stamp = now_utc_iso().replace(":", "").replace("-", "")
    out_md = cdir / "reports" / f"report_{args.case_id}_{stamp}.md"
    write_report_md(out_md, md)

    pdf_msg = None
    if args.pdf:
        out_pdf = cdir / "reports" / f"report_{args.case_id}_{stamp}.pdf"
        pdf_msg = write_report_pdf(out_pdf, md)

    append_coc(coc_path, analyst, "report", {"report_md": str(out_md), "pdf": bool(args.pdf)})
    print(banner())
    print(f"Report written: {out_md}")
    if pdf_msg:
        print(pdf_msg)

# Exercises
def exercises_list(_: argparse.Namespace) -> None:
    print("Exercises:")
    print("  1) run            - run the full 5-exercise lab sequence")
    print("  2) run-tamper      - simulate tampering in a working copy (safe)")
    print("  3) run-corrupt-container - simulate a corrupted container checksum mismatch")

def exercises_run(args: argparse.Namespace) -> None:
    # Full guided sequence
    init_case(args)
    ingest(args)
    make_image(args)

    # simulate deletion and restore
    args2 = argparse.Namespace(**vars(args))
    args2.image_name = "training_image.tar.gz"
    args2.match = ["docs/*"]
    simulate_delete(args2)
    restore_simulated(args2)

    # verify + report
    verify(args)
    report(args)

    print("\nExpected outcomes:")
    print(" - Case folder created with standard structure")
    print(" - Evidence ingested into evidence/ingested_<timestamp> and set read-only (best-effort)")
    print(" - manifest.json and manifest.csv generated with SHA-256 per file")
    print(" - Synthetic training_image.tar.gz created in exports/ and simulation state initialized")
    print(" - 'docs/*' entries moved to deleted list (metadata-only) then restored and extracted to working/restored/")
    print(" - verify outputs PASS unless you alter files")
    print(" - report pack produced in reports/")

def exercises_run_tamper(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    man_json = cdir / "evidence" / "manifest.json"
    if not man_json.exists():
        raise FileNotFoundError("Run ingest first to create an evidence manifest.")
    manifest = json.loads(man_json.read_text(encoding="utf-8"))
    ingest_root = Path(manifest["ingest_root"])
    # Create working copy and tamper there
    working_copy = cdir / "working" / "tamper_copy"
    if working_copy.exists():
        shutil.rmtree(working_copy)
    copy_tree(ingest_root, working_copy)

    # Modify one file in working copy
    # Pick first file in manifest
    first = manifest["files"][0]["path"]
    target = working_copy / Path(first)
    target.write_text(target.read_text(encoding="utf-8", errors="ignore") + "\nTAMPERED\n", encoding="utf-8", errors="ignore")

    ok, mismatches = verify_against_manifest(working_copy, manifest)
    print(banner())
    print("Tamper exercise result (working copy verified against original manifest):")
    print(json.dumps({"ok": ok, "mismatches": mismatches[:10]}, indent=2))
    print("Expected: ok=false and at least one sha256_mismatch. Evidence remains unchanged.")

def exercises_run_corrupt_container(args: argparse.Namespace) -> None:
    cases_dir = Path(args.cases_dir).resolve()
    cdir = case_dir(cases_dir, args.case_id)
    container = cdir / "exports" / "training_image.tar.gz"
    if not container.exists():
        raise FileNotFoundError("Run make-image first to create training_image.tar.gz")

    corrupt = cdir / "exports" / "training_image_CORRUPT.tar.gz"
    shutil.copy2(container, corrupt)

    # Flip one byte near the end (safe corruption)
    data = corrupt.read_bytes()
    if len(data) < 100:
        raise ValueError("Container unexpectedly small.")
    idx = len(data) - 50
    flipped = (data[idx] ^ 0xFF).to_bytes(1, "little")
    corrupt.write_bytes(data[:idx] + flipped + data[idx+1:])

    orig_sha = sha256_file(container)
    corrupt_sha = sha256_file(corrupt)

    print(banner())
    print("Corrupted container exercise:")
    print(json.dumps({"original": {"name": container.name, "sha256": orig_sha},
                      "corrupt": {"name": corrupt.name, "sha256": corrupt_sha}}, indent=2))
    print("Expected: SHA-256 differs; integrity check fails for the corrupt copy.")

def main() -> None:
    parser = argparse.ArgumentParser(prog="zd_drt", description=f"{TOOL_NAME} (training simulator)\n\n{BANNER}")
    parser.add_argument("--cases-dir", required=False, default="./cases", help="Root directory for cases (default: ./cases)")

    sub = parser.add_subparsers(dest="cmd", required=True)

    p_init = sub.add_parser("init-case", help="Initialize a new case")
    p_init.add_argument("--case-id", required=True)
    p_init.add_argument("--analyst", required=True)
    p_init.add_argument("--auth", required=True, help="Authorization statement")
    p_init.set_defaults(func=init_case)

    p_ing = sub.add_parser("ingest", help="Ingest a training folder into evidence/ (safe copy + hash)")
    p_ing.add_argument("--case-id", required=True)
    p_ing.add_argument("--input", required=True, help="Input folder of training files")
    p_ing.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_ing.set_defaults(func=ingest)

    p_img = sub.add_parser("make-image", help="Generate a synthetic training container image (.tar.gz)")
    p_img.add_argument("--case-id", required=True)
    p_img.add_argument("--output-name", required=False, help="Container filename (default: training_image.tar.gz)")
    p_img.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_img.set_defaults(func=make_image)

    p_sd = sub.add_parser("simulate-delete", help="Simulate deletion by removing entries from active manifest (metadata only)")
    p_sd.add_argument("--case-id", required=True)
    p_sd.add_argument("--image-name", required=True, help="Container name in exports/ (e.g., training_image.tar.gz)")
    p_sd.add_argument("--match", action="append", required=True, help="Glob match patterns (repeatable), e.g., --match 'docs/*'")
    p_sd.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_sd.set_defaults(func=simulate_delete)

    p_rs = sub.add_parser("restore-simulated", help="Restore simulated-deleted entries and extract from synthetic container to working/")
    p_rs.add_argument("--case-id", required=True)
    p_rs.add_argument("--image-name", required=True, help="Container name in exports/ (e.g., training_image.tar.gz)")
    p_rs.add_argument("--match", action="append", required=True, help="Glob match patterns (repeatable)")
    p_rs.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_rs.set_defaults(func=restore_simulated)

    p_v = sub.add_parser("verify", help="Verify evidence and container integrity (training-grade)")
    p_v.add_argument("--case-id", required=True)
    p_v.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_v.set_defaults(func=verify)

    p_r = sub.add_parser("report", help="Generate a human-readable report pack (Markdown; PDF optional)")
    p_r.add_argument("--case-id", required=True)
    p_r.add_argument("--pdf", action="store_true", help="Also write a simple PDF (if reportlab installed)")
    p_r.add_argument("--analyst", required=False, help="Analyst name (defaults to case analyst)")
    p_r.set_defaults(func=report)

    p_ex = sub.add_parser("exercises", help="Built-in training exercises")
    ex_sub = p_ex.add_subparsers(dest="excmd", required=True)

    p_ex_list = ex_sub.add_parser("list", help="List exercises")
    p_ex_list.set_defaults(func=exercises_list)

    p_ex_run = ex_sub.add_parser("run", help="Run full lab sequence (5 exercises)")
    p_ex_run.add_argument("--case-id", required=True)
    p_ex_run.add_argument("--analyst", required=True)
    p_ex_run.add_argument("--auth", required=True)
    p_ex_run.add_argument("--input", required=False, default="./examples/sample_input")
    p_ex_run.add_argument("--output-name", required=False, default="training_image.tar.gz")
    p_ex_run.set_defaults(func=exercises_run)

    p_ex_t = ex_sub.add_parser("run-tamper", help="Simulate tampering in a working copy (safe)")
    p_ex_t.add_argument("--case-id", required=True)
    p_ex_t.set_defaults(func=exercises_run_tamper)

    p_ex_c = ex_sub.add_parser("run-corrupt-container", help="Simulate a corrupted container checksum mismatch")
    p_ex_c.add_argument("--case-id", required=True)
    p_ex_c.set_defaults(func=exercises_run_corrupt_container)

    args = parser.parse_args()
    # show banner on every run
    # do not enforce auth on every command (training ergonomics), but store it in case.json
    args.func(args)

if __name__ == "__main__":
    main()
