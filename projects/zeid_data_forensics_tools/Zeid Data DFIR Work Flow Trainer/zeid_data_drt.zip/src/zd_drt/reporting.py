from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

from .utils import ensure_dir, now_utc_iso, BANNER
from .logging import load_coc, verify_coc_hash_chain

def render_markdown(case_meta: dict[str, Any], evidence_manifest: Optional[dict[str, Any]], verify_summary: dict[str, Any], sim_summary: dict[str, Any], coc_entries: list[dict[str, Any]], coc_ok: bool, coc_issues: list[str]) -> str:
    lines: list[str] = []
    lines.append(f"# Zeid Data — DRT Report")
    lines.append("")
    lines.append(f"**{BANNER}**")
    lines.append("")
    lines.append("## Case metadata")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(case_meta, indent=2))
    lines.append("```")
    lines.append("")
    lines.append("## Integrity verification summary")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(verify_summary, indent=2))
    lines.append("```")
    lines.append("")
    lines.append("## Simulated deletion / restore summary")
    lines.append("")
    lines.append("```json")
    lines.append(json.dumps(sim_summary, indent=2))
    lines.append("```")
    lines.append("")

    if evidence_manifest:
        lines.append("## Evidence manifest (snapshot)")
        lines.append("")
        lines.append(f"- File count: {evidence_manifest.get('file_count')}")
        lines.append(f"- Manifest SHA-256: `{evidence_manifest.get('manifest_sha256')}`")
        lines.append("")
        lines.append("### Files")
        lines.append("")
        lines.append("| Path | Size | SHA-256 |")
        lines.append("|---|---:|---|")
        for f in evidence_manifest.get("files", [])[:200]:
            lines.append(f"| `{f['path']}` | {f['size']} | `{f['sha256']}` |")
        if len(evidence_manifest.get("files", [])) > 200:
            lines.append("")
            lines.append("> Truncated display to 200 entries. Full manifest is stored in the case folder.")
        lines.append("")

    lines.append("## Chain of custody")
    lines.append("")
    lines.append(f"- Hash-chain verification: **{'PASS' if coc_ok else 'FAIL'}**")
    if coc_issues:
        lines.append("")
        lines.append("### Issues")
        lines.append("")
        for i in coc_issues:
            lines.append(f"- {i}")
    lines.append("")
    lines.append("### Entries")
    lines.append("")
    lines.append("| Timestamp (UTC) | Analyst | Action | Details | Entry Hash |")
    lines.append("|---|---|---|---|---|")
    for e in coc_entries[-200:]:
        lines.append(f"| {e.get('timestamp_utc','')} | {e.get('analyst','')} | {e.get('action','')} | `{json.dumps(e.get('details',{}), sort_keys=True)}` | `{e.get('entry_hash','')}` |")
    if len(coc_entries) > 200:
        lines.append("")
        lines.append("> Truncated display to last 200 entries. Full log is stored in the case folder.")
    lines.append("")

    lines.append("## Notes")
    lines.append("")
    lines.append("- This report is generated for training purposes only.")
    lines.append("- No raw-disk operations are performed by DRT.")
    lines.append("")
    lines.append(f"_Generated: {now_utc_iso()}_")
    return "\n".join(lines)

def write_report_md(out_path: Path, md: str) -> None:
    ensure_dir(out_path.parent)
    out_path.write_text(md, encoding="utf-8")

def write_report_pdf(out_path: Path, md: str) -> str:
    """
    Best-effort: uses reportlab if available. Returns a status message.
    """
    try:
        from reportlab.lib.pagesizes import letter
        from reportlab.pdfgen import canvas
    except Exception:
        return "PDF not generated: reportlab not available."

    ensure_dir(out_path.parent)
    c = canvas.Canvas(str(out_path), pagesize=letter)
    width, height = letter
    y = height - 50
    c.setFont("Helvetica", 10)

    # Very simple rendering: wrap long lines
    for raw_line in md.splitlines():
        line = raw_line.replace("\t", "    ")
        while len(line) > 110:
            c.drawString(50, y, line[:110])
            line = line[110:]
            y -= 12
            if y < 50:
                c.showPage()
                c.setFont("Helvetica", 10)
                y = height - 50
        c.drawString(50, y, line)
        y -= 12
        if y < 50:
            c.showPage()
            c.setFont("Helvetica", 10)
            y = height - 50

    c.save()
    return "PDF generated."

def coc_status(coc_path: Path) -> tuple[list[dict[str, Any]], bool, list[str]]:
    entries = load_coc(coc_path)
    ok, issues = verify_coc_hash_chain(coc_path)
    return entries, ok, issues
