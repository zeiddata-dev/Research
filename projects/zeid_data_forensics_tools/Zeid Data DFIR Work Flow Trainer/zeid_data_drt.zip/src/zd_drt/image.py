from __future__ import annotations

import json
import os
import random
import shutil
import tarfile
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Optional

from .core import build_manifest, write_manifest_json, sha256_file
from .utils import ensure_dir, now_utc_iso, match_globs

SYNTHETIC_LAYOUT = [
    ("docs/incident_summary.txt", "Synthetic incident summary.\nThis dataset is authorized for training.\n"),
    ("docs/user_story.md", "# Training Story\n\nThis is a synthetic narrative for training.\n"),
    ("logs/app.log", "2026-02-08T00:00:01Z INFO app started\n2026-02-08T00:01:44Z WARN unusual request\n"),
    ("exports/db_dump.sql", "-- Synthetic SQL dump\nCREATE TABLE example(id INTEGER PRIMARY KEY, note TEXT);\nINSERT INTO example(note) VALUES('synthetic');\n"),
]

# 1x1 PNG
_TINY_PNG_B64 = (
    "iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR4nGNgYAAAAAMA"
    "ASsJTYQAAAAASUVORK5CYII="
)

def generate_synthetic_dataset(root: Path) -> None:
    import base64
    ensure_dir(root)
    for rel, content in SYNTHETIC_LAYOUT:
        p = root / rel
        ensure_dir(p.parent)
        p.write_text(content, encoding="utf-8")
    # Add tiny image
    img = root / "images/diagram.png"
    ensure_dir(img.parent)
    img.write_bytes(base64.b64decode(_TINY_PNG_B64))

    # Add a small sqlite DB for realism (standard lib)
    import sqlite3
    db_path = root / "db/training.db"
    ensure_dir(db_path.parent)
    con = sqlite3.connect(db_path)
    try:
        cur = con.cursor()
        cur.execute("CREATE TABLE IF NOT EXISTS artifacts(id INTEGER PRIMARY KEY, name TEXT, note TEXT)")
        cur.execute("INSERT INTO artifacts(name, note) VALUES(?, ?)", ("alpha", "synthetic"))
        con.commit()
    finally:
        con.close()

def create_training_image(container_path: Path, dataset_root: Path) -> dict[str, Any]:
    """
    Create a tar.gz container from dataset_root and embed a manifest JSON alongside.
    Returns container metadata.
    """
    ensure_dir(container_path.parent)

    # Build file manifest from dataset_root (before tar)
    records = build_manifest(dataset_root)
    manifest_tmp = dataset_root / "__container_manifest.json"
    write_manifest_json(manifest_tmp, records, extra={"scope": "synthetic_training_container"})

    # Write tar.gz
    with tarfile.open(container_path, "w:gz") as tf:
        for p in dataset_root.rglob("*"):
            if p.is_file():
                arcname = str(p.relative_to(dataset_root)).replace("\\", "/")
                tf.add(p, arcname=arcname)

    # Compute container sha256
    container_sha = sha256_file(container_path)

    # Cleanup temp manifest file (it is already inside tar)
    if manifest_tmp.exists():
        try:
            manifest_tmp.unlink()
        except Exception:
            pass

    return {
        "container_name": container_path.name,
        "container_path": str(container_path),
        "container_sha256": container_sha,
        "created_utc": now_utc_iso(),
    }

def list_container_files(container_path: Path) -> list[str]:
    with tarfile.open(container_path, "r:gz") as tf:
        return sorted([m.name for m in tf.getmembers() if m.isfile()])

def extract_from_container(container_path: Path, members: list[str], out_dir: Path) -> list[str]:
    """
    Extract selected members to out_dir.
    """
    ensure_dir(out_dir)
    extracted: list[str] = []
    with tarfile.open(container_path, "r:gz") as tf:
        for name in members:
            m = tf.getmember(name)
            if not m.isfile():
                continue
            tf.extract(m, path=out_dir)  # training-only; extracts relative paths
            extracted.append(name)
    return extracted

def compute_container_member_sha256(container_path: Path, member_name: str) -> str:
    import hashlib
    h = hashlib.sha256()
    with tarfile.open(container_path, "r:gz") as tf:
        f = tf.extractfile(member_name)
        if f is None:
            raise FileNotFoundError(member_name)
        while True:
            b = f.read(8 * 1024 * 1024)
            if not b:
                break
            h.update(b)
    return h.hexdigest()

def ensure_sim_state(sim_dir: Path, container_files: list[str]) -> Path:
    ensure_dir(sim_dir)
    active = sim_dir / "active_manifest.json"
    history = sim_dir / "history.jsonl"
    if not active.exists():
        payload = {
            "generated_utc": now_utc_iso(),
            "active_files": container_files,
            "deleted_files": [],
        }
        active.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    if not history.exists():
        history.write_text("", encoding="utf-8")
    return active

def load_active_manifest(active_manifest_path: Path) -> dict[str, Any]:
    return json.loads(active_manifest_path.read_text(encoding="utf-8"))

def write_history(history_path: Path, event: dict[str, Any]) -> None:
    ensure_dir(history_path.parent)
    with history_path.open("a", encoding="utf-8") as f:
        f.write(json.dumps(event, sort_keys=True) + "\n")

def simulate_delete(active_manifest_path: Path, history_path: Path, patterns: list[str], actor: str) -> dict[str, Any]:
    state = load_active_manifest(active_manifest_path)
    active_files: list[str] = state.get("active_files", [])
    deleted_files: list[str] = state.get("deleted_files", [])

    to_delete = match_globs(active_files, patterns)
    if not to_delete:
        return {"deleted": [], "message": "No files matched patterns."}

    new_active = [p for p in active_files if p not in to_delete]
    new_deleted = sorted(set(deleted_files + to_delete))

    state["active_files"] = new_active
    state["deleted_files"] = new_deleted
    state["updated_utc"] = now_utc_iso()
    active_manifest_path.write_text(json.dumps(state, indent=2), encoding="utf-8")

    event = {
        "timestamp_utc": now_utc_iso(),
        "actor": actor,
        "action": "simulate_delete",
        "patterns": patterns,
        "files": to_delete,
    }
    write_history(history_path, event)
    return {"deleted": to_delete, "message": f"Simulated deletion of {len(to_delete)} file(s). (metadata only)"}

def restore_simulated(active_manifest_path: Path, history_path: Path, patterns: list[str], actor: str) -> dict[str, Any]:
    state = load_active_manifest(active_manifest_path)
    deleted_files: list[str] = state.get("deleted_files", [])
    active_files: list[str] = state.get("active_files", [])

    to_restore = match_globs(deleted_files, patterns)
    if not to_restore:
        return {"restored": [], "message": "No deleted files matched patterns."}

    new_deleted = [p for p in deleted_files if p not in to_restore]
    new_active = sorted(set(active_files + to_restore))

    state["active_files"] = new_active
    state["deleted_files"] = new_deleted
    state["updated_utc"] = now_utc_iso()
    active_manifest_path.write_text(json.dumps(state, indent=2), encoding="utf-8")

    event = {
        "timestamp_utc": now_utc_iso(),
        "actor": actor,
        "action": "restore_simulated",
        "patterns": patterns,
        "files": to_restore,
    }
    write_history(history_path, event)
    return {"restored": to_restore, "message": f"Restored {len(to_restore)} file(s) in metadata (simulation)."}
