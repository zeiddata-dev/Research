# Zeid Data CloakCheck Pack
> Cloaked phishing via server-side filtering — “you never saw the real page.”

This repo-style drop includes:
- A differential URL fetch script that pulls the same URL using multiple client profiles and compares results
- Detection templates (Splunk, Sentinel, Elastic, Sigma)
- IOC schemas (CSV/JSON) + a small STIX 2.1 bundle example
- A mini whitepaper (Markdown + PDF)
- A scorecard + evidence bundle template
- A LinkedIn post you can paste and ship

## Quick start
1) Create a venv and install deps:
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
source .venv/bin/activate
pip install -r zeid_data_requirements.txt
```

2) Run differential fetch:
```bash
python scripts/zeid_data_differential_fetch.py --url "https://example.com/suspicious" --out runs
```

3) Compare runs:
```bash
python scripts/zeid_data_compare_runs.py --runs runs --report runs/zeid_data_comparison_report.md
```

## What “CloakCheck” is looking for
- Redirect chains that differ by User-Agent / Accept-Language / Referrer
- Content hash and content-length drift across “profiles”
- Suspicious 30x hops (especially to newly observed domains)
- “Clean for scanners” behavior (benign content for one profile, kit for another)

## Safety / ethics
Use this only on URLs you are authorized to test (your org, your lab, or with explicit permission).
This pack is designed for detection and analysis, not exploitation.

## Layout
- `scripts/` — collection + comparison tools
- `detections/` — starter queries and Sigma rule
- `templates/` — IOC schemas and STIX example
- `checklists/` — scorecard + evidence bundle template
- `data/` — small synthetic sample telemetry for demo/training
- `zeid_data_whitepaper.*` — mini whitepaper

## License
MIT — see `zeid_data_LICENSE.txt`
