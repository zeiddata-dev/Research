This is a big reason automated scanners miss it: they don’t “look” like the intended victim, so they never get the real page. 🧪🕵️

Cloaked phishing kits do server-side filtering *before you ever see the landing page*.

When someone clicks, the kit runs gate checks like:
☑️ country / region
☑️ ISP or ASN (and it often blocks datacenters, VPNs, scanners)
☑️ device type (mobile vs desktop)
☑️ headers and “browser vibes” (UA, language, referrer, cookies)
☑️ time windows

If you don’t match the target profile? Congrats, you get redirected to something boring and benign.
If you *do* match? You get the real kit.

Takeaway: don’t confuse “our gateway scanned it” with “we’re safe.”
A script-kiddie kit with basic cloaking can look clean from one vantage point and still cook your users.

I published a small drop: **CloakCheck** — a differential URL fetch tool + detections + templates:
🧾 evidence bundle template
🔎 Splunk / Sentinel / Elastic starter queries
🧩 IOC schema + STIX example
📄 mini whitepaper

If it didn’t generate evidence, it didn’t happen. 🧾😈
