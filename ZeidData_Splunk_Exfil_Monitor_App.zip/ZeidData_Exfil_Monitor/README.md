# Zeid Data | Exfiltration Monitor (Splunk App Skeleton)

A lightweight Splunk app skeleton that provides:
- **Saved Searches (detections)** for outbound volume and exfil indicators
- **Dashboards** for triage and trending
- **Allowlist lookups** to reduce noise

Designed to work best when your data is **CIM-mapped** (Network_Traffic, Web, DNS, Authentication).

## Install
1. Copy the folder `ZeidData_Exfil_Monitor/` to:
   - Splunk Enterprise: `$SPLUNK_HOME/etc/apps/`
   - or upload the packaged ZIP via **Apps > Manage Apps > Install app from file**
2. Restart Splunk.

## Enable detections (safe defaults)
All detections ship **disabled** (`enableSched=0`).
- Go to **Settings > Searches, reports, and alerts**
- Filter searches starting with `ZD Exfil -`
- Enable the ones that match your data coverage
- Tune thresholds + add allowlists

## Tune environment-specific settings
Edit macros in:
- `default/macros.conf` (best practice: copy to `local/macros.conf` so upgrades don’t overwrite)

Key macros:
- `zd_exfil_threshold_gb` (default 5 GB per hour)
- `zd_exfil_threshold_mb_cloud` (default 500 MB / 30m)
- `zd_cloud_storage_domain_regex` (cloud upload domains)

## Noise reduction
Edit allowlist:
- `lookups/zeid_exfil_dest_allowlist.csv`

Add:
- `dest_ip` for known-good external IPs
- `dest_domain` for known-good domains (enterprise SaaS, backups, etc.)

## Data requirements (recommended)
- Network telemetry with **bytes_out** (firewall / NDR / NetFlow-like)
- Proxy/web gateway logs with **bytes_out** and **url_domain**
- DNS query logs
- Auth logs (Windows, VPN, SSO, cloud)

---
© Zeid Data. Defensive monitoring only.
