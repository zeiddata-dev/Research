# HOWTO — Implement the 4 deliverables

## 1) Host group segmentation + policy scoping
Goal: make tuning safe by avoiding “global” changes.

**Steps**
1. Build your host-group taxonomy (see `01-host-groups/host_group_taxonomy.md`).
2. Implement tags in your CMDB / RMM / gold image:
   - Example: `zd_tier=server`, `zd_env=prod`, `zd_role=dc`, `zd_team=data`
3. Create Falcon host groups from those tags.
4. Fill in the `01-host-groups/policy_scope_matrix.csv` and attach it to change control.

**Audit output**
- Host group list + membership criteria
- Policy assignment matrix (who gets what protections)
- Exceptions register (any non-standard policy assignments)

---

## 2) Top-10 noise cleanup with exclusions (guardrailed)
Goal: reduce noise *without* losing detection coverage.

**Steps**
1. Pull last 14–30 days of detections (your SIEM/LogScale or Falcon UI export).
2. Identify top noisy patterns and categorize:
   - **Known-good binary** (signed + consistent path) → consider **certificate-based** exclusion
   - **Known-good file/path** (not stable signer) → **ML exclusion** (narrow scope)
   - **Known-good behavior** (admin tool pattern) → **IOA exclusion** (behavior-specific)
3. For each candidate exclusion:
   - Add business justification + ticket ID
   - Set an expiration date (30–90 days)
   - Scope it to the smallest host group possible
4. Track everything in `02-exclusions/exclusions_register.csv`.

**Implementation**
- Use the scripts in `02-exclusions/scripts/` to export, validate, and create exclusions.
- Start with export + validate; only then create.

---

## 3) Falcon Fusion triage automation (blueprints)
Goal: route + enrich + standardize outcomes so only “real” items page humans.

Use `03-fusion/fusion_workflow_blueprints.md`.
Start with two flows:
- **Route by asset tier + confidence** (VIP/Server/Workstation)
- **Auto-ticket only when threshold met** (otherwise add context and close as “expected activity”)

---

## 4) Monthly evidence bundle
Goal: one-click-ish evidence pack you can regenerate and hash.

Run:
```bash
python 04-evidence-bundle/scripts/build_monthly_evidence_bundle.py --days 30 --out evidence_out
```

Outputs:
- `rtr_audit_sessions.json`
- `ml_exclusions.json`
- `ioa_exclusions.json`
- `cert_exclusions.json`
- `scheduled_reports.json` (+ executions, if accessible)
- `manifest_sha256.json`

> Not all tenants have all APIs enabled. The script degrades gracefully and records what it could not access.

---

## Common pitfalls
- Broad path wildcards (creates blind spots)
- Global exclusions (avoid; scope to host groups)
- No expiration / no ticket reference (auditors hate this)
- “Sensor visibility exclusions” used as a first resort (avoid unless you truly need it)
