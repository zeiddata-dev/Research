# RTR triage script catalog (recommended)

Use RTR scripts to standardize evidence collection **when** a detection is high-confidence.

## Minimal, safe collection (Windows)
- Running processes + parent chains
- Network connections
- Logged-on users
- Recent scheduled tasks / services
- Hash suspicious binaries (do not execute unknown code)

## Minimal, safe collection (Linux)
- ps tree
- netstat/ss
- last/logins
- systemd units

## Notes
- Keep scripts read-only by default.
- Record outputs in your ticket system or evidence bundle.
- RTR actions produce audit logs; keep those for evidence.
