# Falcon Fusion workflow blueprints (audit + noise reduction)

These are **blueprints** you can implement in Falcon Fusion (no-code).

## Workflow A — Route detections by asset tier
**Trigger:** Detection created

**Logic (example)**
1. Lookup host group:
   - If `TIER-DC` or `TIER-SERVER-PROD`: escalate priority, notify SecOps on-call
   - If `TIER-VIP`: notify + open ticket
   - Else: standard queue

**Actions**
- Add tag / label to detection (e.g., `ZD_TIER=SERVER_PROD`)
- Add comment with enrichment fields
- Create ticket only for high-signal conditions

## Workflow B — Auto-ticket only above threshold
**Trigger:** Detection created

**Conditions (example)**
- Severity >= High
- AND confidence >= Medium
- AND not in “Expected Admin Activity” lookup list

**Actions**
- Create ticket (Jira/ServiceNow/email)
- Assign to queue based on tier

## Workflow C — Scheduled evidence workflow (optional)
**Trigger:** Scheduled (monthly)
**Action:** Run a workflow that emails a checklist or posts to Teams/Slack with:
- link to evidence bundle folder location
- reminder to review expiring exclusions

> Scheduled workflows are supported. Use this to enforce monthly hygiene.
