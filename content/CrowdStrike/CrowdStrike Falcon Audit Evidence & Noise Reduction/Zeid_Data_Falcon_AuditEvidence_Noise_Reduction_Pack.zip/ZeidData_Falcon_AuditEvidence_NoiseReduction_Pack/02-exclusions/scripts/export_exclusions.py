import os, json, argparse, datetime, hashlib
from pathlib import Path
from dotenv import load_dotenv

def utc_now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def load_creds():
    load_dotenv()
    cid = os.getenv("FALCON_CLIENT_ID")
    csec = os.getenv("FALCON_CLIENT_SECRET")
    cloud = os.getenv("FALCON_CLOUD") or None
    if not cid or not csec:
        raise SystemExit("Missing FALCON_CLIENT_ID / FALCON_CLIENT_SECRET in environment.")
    return cid, csec, cloud

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

from falconpy import APIHarnessV2

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--out", required=True, help="Output folder")
    args = p.parse_args()

    cid, csec, cloud = load_creds()
    api = APIHarnessV2(client_id=cid, client_secret=csec, base_url=cloud)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    exports = {}

    # ML exclusions
    try:
        r = api.command("getMLExclusionsV1", parameters={})
        exports["ml_exclusions"] = r
        (out / "ml_exclusions.json").write_text(json.dumps(r, indent=2), encoding="utf-8")
    except Exception as e:
        exports["ml_exclusions_error"] = str(e)

    # Cert-based exclusions
    try:
        r = api.command("cbExclusionsGetV1", parameters={})
        exports["cert_exclusions"] = r
        (out / "cert_exclusions.json").write_text(json.dumps(r, indent=2), encoding="utf-8")
    except Exception as e:
        exports["cert_exclusions_error"] = str(e)

    # IOA exclusions (note: API names can vary by tenant/module)
    # We record gracefully if unavailable.
    try:
        r = api.command("queryIOAExclusionsV1", parameters={})
        exports["ioa_exclusions"] = r
        (out / "ioa_exclusions.json").write_text(json.dumps(r, indent=2), encoding="utf-8")
    except Exception as e:
        exports["ioa_exclusions_error"] = str(e)

    (out / "export_summary.json").write_text(json.dumps(exports, indent=2), encoding="utf-8")

    # Integrity manifest
    manifest = {"generated_at": utc_now_iso(), "files": {}}
    for fp in out.glob("*.json"):
        manifest["files"][fp.name] = {"sha256": sha256_file(fp), "bytes": fp.stat().st_size}
    (out / "manifest_sha256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("Export complete:", out)

if __name__ == "__main__":
    main()
