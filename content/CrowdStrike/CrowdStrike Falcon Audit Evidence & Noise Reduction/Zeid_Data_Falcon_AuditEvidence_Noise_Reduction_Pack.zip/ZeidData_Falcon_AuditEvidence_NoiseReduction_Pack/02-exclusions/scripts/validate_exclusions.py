import os, json, argparse, datetime, hashlib
from pathlib import Path
from dotenv import load_dotenv

def utc_now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def load_creds():
    load_dotenv()
    cid = os.getenv("FALCON_CLIENT_ID")
    csec = os.getenv("FALCON_CLIENT_SECRET")
    cloud = os.getenv("FALCON_CLOUD") or None
    if not cid or not csec:
        raise SystemExit("Missing FALCON_CLIENT_ID / FALCON_CLIENT_SECRET in environment.")
    return cid, csec, cloud

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

import csv

def validate_date(s):
    try:
        datetime.date.fromisoformat(s)
        return True
    except Exception:
        return False

def read_csv(path):
    with open(path, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--ml-csv", required=True)
    p.add_argument("--ioa-csv", required=True)
    args = p.parse_args()

    ml = read_csv(args.ml_csv)
    ioa = read_csv(args.ioa_csv)

    problems = []

    for i, row in enumerate(ml, start=2):
        for key in ["name","pattern","pattern_type","expires_on","scope_host_group"]:
            if not row.get(key):
                problems.append(f"ML row {i}: missing {key}")
        if row.get("expires_on") and not validate_date(row["expires_on"]):
            problems.append(f"ML row {i}: invalid expires_on {row['expires_on']}")

    for i, row in enumerate(ioa, start=2):
        for key in ["name","rule_group_id","rule_id","expires_on","scope_host_group"]:
            if not row.get(key):
                problems.append(f"IOA row {i}: missing {key}")
        if row.get("expires_on") and not validate_date(row["expires_on"]):
            problems.append(f"IOA row {i}: invalid expires_on {row['expires_on']}")

    if problems:
        print("VALIDATION FAILED:")
        for pr in problems:
            print(" -", pr)
        raise SystemExit(2)
    print("VALIDATION OK")

if __name__ == "__main__":
    main()
