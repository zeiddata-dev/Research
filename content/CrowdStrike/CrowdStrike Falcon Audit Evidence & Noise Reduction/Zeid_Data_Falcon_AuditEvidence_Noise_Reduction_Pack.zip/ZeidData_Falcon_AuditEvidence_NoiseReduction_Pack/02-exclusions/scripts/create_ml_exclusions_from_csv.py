import os, json, argparse, datetime, hashlib
from pathlib import Path
from dotenv import load_dotenv

def utc_now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def load_creds():
    load_dotenv()
    cid = os.getenv("FALCON_CLIENT_ID")
    csec = os.getenv("FALCON_CLIENT_SECRET")
    cloud = os.getenv("FALCON_CLOUD") or None
    if not cid or not csec:
        raise SystemExit("Missing FALCON_CLIENT_ID / FALCON_CLIENT_SECRET in environment.")
    return cid, csec, cloud

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

import csv
from falconpy import APIHarnessV2

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--csv", required=True)
    p.add_argument("--dry-run", action="store_true")
    args = p.parse_args()

    cid, csec, cloud = load_creds()
    api = APIHarnessV2(client_id=cid, client_secret=csec, base_url=cloud)

    with open(args.csv, newline="", encoding="utf-8") as f:
        rows = list(csv.DictReader(f))

    created = []
    for row in rows:
        body = {
            "comment": row.get("comment") or "",
            "description": row.get("description") or "",
            "name": row["name"],
            "pattern": row["pattern"],
            "pattern_type": row["pattern_type"],
        }
        if args.dry_run:
            created.append({"dry_run": True, "body": body})
            continue

        # FalconPy provides service collections; APIHarness can call operations by OpenAPI id.
        # This operation name is commonly `createExclusionsV1` under ML Exclusions.
        resp = api.command("createExclusionsV1", body=body)
        created.append({"body": body, "response": resp})

    print(json.dumps({"created": created}, indent=2))

if __name__ == "__main__":
    main()
