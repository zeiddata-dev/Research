# Exclusion policy (noise reduction with guardrails)

## Principles
1. **Scope narrowly** (host group first).
2. **Expire everything** (30–90 days default).
3. **Justify** with ticket ID + business owner approval.
4. Prefer:
   - **Cert-based** (best) → stable vendor signer
   - **ML exclusion** → known-good file/path
   - **IOA exclusion** → benign behavior pattern
   - **Sensor visibility** → last resort

## Required fields (for audit)
- Exclusion name
- Type (ML / IOA / cert)
- Target group(s)
- Rationale
- Ticket ID
- Approved by + date
- Expiration date
- Review outcome (renew/retire/modify)

## Where to track
Use `exclusions_register.csv` as your control record.
