# Zeid Data — CrowdStrike Falcon Customization Pack
**Focus:** Audit evidence + noise reduction (practical, repeatable, and defensible).

This pack implements four deliverables:

1. **Host group segmentation + policy scoping** (safer tuning + cleaner audits)
2. **Top-10 noise cleanup** using the correct exclusion types (ML / IOA / cert-based) with guardrails
3. **Falcon Fusion triage automation blueprints** (route, enrich, and standardize outcomes)
4. **Monthly evidence bundle runbook + export scripts** (RTR audit, exclusions/policy baselines, scheduled reports)

> Disclaimer: This is operational tooling + templates. You must validate in your tenant, with your change-control process.

---

## Quick start
1) Install Python 3.10+ on a secure admin workstation.
2) Copy `02-exclusions/scripts/cs_env_example.env` to `.env` and set:
- `FALCON_CLIENT_ID`
- `FALCON_CLIENT_SECRET`
- `FALCON_CLOUD` (optional; example: `us-1`)

3) Install deps:
```bash
pip install -r 02-exclusions/scripts/requirements.txt
```

4) Dry-run validate your CSVs first:
```bash
python 02-exclusions/scripts/validate_exclusions.py --ml-csv 02-exclusions/sample_ml_exclusions.csv --ioa-csv 02-exclusions/sample_ioa_exclusions.csv
```

5) Generate an evidence bundle folder (local):
```bash
python 04-evidence-bundle/scripts/build_monthly_evidence_bundle.py --days 30 --out evidence_out
```

---

## What you’ll get out of this
- A scoped **policy + exclusion** approach that reduces alert spam without creating a “silent failure” zone.
- A monthly “**show me the proof**” evidence set you can hand to auditors:
  - RTR audit sessions and commands
  - Exclusions inventory + rationale
  - Scheduled report executions + artifacts (if used)
  - Integrity manifest (SHA256)

---

## Folder map
- `01-host-groups/` — taxonomy, tagging strategy, scope matrix
- `02-exclusions/` — registers, policies, sample CSVs, scripts (FalconPy)
- `03-fusion/` — workflow blueprints + routing YAML
- `04-evidence-bundle/` — runbook + evidence scripts + templates
- `99-ops/` — changelog, security notes

---

## License
MIT (see `LICENSE.txt`)
