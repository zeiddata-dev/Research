# Changelog
## 0.1.0 (2026-01-27)
- Initial release: host groups, exclusion guardrails, Fusion blueprints, monthly evidence bundle scripts
