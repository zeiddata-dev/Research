# Security notes

- Do not hardcode API credentials.
- Store generated evidence bundles in a restricted location.
- Treat exclusions as controlled change: ticket + approval + expiration.
- Review API client scopes regularly; least privilege.
