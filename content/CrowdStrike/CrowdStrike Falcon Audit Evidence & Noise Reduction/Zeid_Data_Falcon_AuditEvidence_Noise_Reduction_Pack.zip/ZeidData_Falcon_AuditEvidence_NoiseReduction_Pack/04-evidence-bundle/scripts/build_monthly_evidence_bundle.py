import os, json, argparse, datetime, hashlib
from pathlib import Path
from dotenv import load_dotenv

def utc_now_iso():
    return datetime.datetime.utcnow().replace(microsecond=0).isoformat() + "Z"

def load_creds():
    load_dotenv()
    cid = os.getenv("FALCON_CLIENT_ID")
    csec = os.getenv("FALCON_CLIENT_SECRET")
    cloud = os.getenv("FALCON_CLOUD") or None
    if not cid or not csec:
        raise SystemExit("Missing FALCON_CLIENT_ID / FALCON_CLIENT_SECRET in environment.")
    return cid, csec, cloud

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024*1024), b""):
            h.update(chunk)
    return h.hexdigest()

import json
from pathlib import Path
from falconpy import APIHarnessV2

def safe_call(api, operation_id, *, parameters=None, body=None):
    try:
        if body is None:
            r = api.command(operation_id, parameters=parameters or {})
        else:
            r = api.command(operation_id, body=body, parameters=parameters or {})
        return {"ok": True, "data": r}
    except Exception as e:
        return {"ok": False, "error": str(e), "operation_id": operation_id}

def main():
    p = argparse.ArgumentParser()
    p.add_argument("--days", type=int, default=30)
    p.add_argument("--out", required=True, help="Output folder")
    args = p.parse_args()

    cid, csec, cloud = load_creds()
    api = APIHarnessV2(client_id=cid, client_secret=csec, base_url=cloud)

    out = Path(args.out)
    out.mkdir(parents=True, exist_ok=True)

    summary = {"generated_at": utc_now_iso(), "days": args.days, "artifacts": {}}

    # RTR audit sessions (FalconPy / RTRAuditSessions maps to /real-time-response-audit/ endpoints)
    # Operation IDs may differ by SDK version; we try common ones and record failures.
    candidates_rtr = ["AuditSessions", "audit_sessions", "getRTRAuditSessions", "getRTRAuditSessionsV1", "rtraudit_sessions"]
    rtr = None
    for op in ["auditSessions", "AuditSessions", "audit_sessions", "rtraudit_sessions", "audit_sessions_v1", "combinedRTRAuditSessionsV1", "combinedRTRAuditSessions"]:
        # We'll attempt a call and accept first success.
        res = safe_call(api, op, parameters={"limit": 500})
        if res["ok"]:
            rtr = res["data"]
            summary["artifacts"]["rtr_audit_sessions"] = {"operation": op, "status": "ok"}
            (out / "rtr_audit_sessions.json").write_text(json.dumps(rtr, indent=2), encoding="utf-8")
            break
    if rtr is None:
        summary["artifacts"]["rtr_audit_sessions"] = {"status": "error", "note": "RTR Audit operation id differs by tenant/SDK; consult Falcon OpenAPI / falconpy Real Time Response Audit collection."}

    # ML exclusions
    ml = safe_call(api, "getMLExclusionsV1")
    summary["artifacts"]["ml_exclusions"] = {"status": "ok" if ml["ok"] else "error", "operation": "getMLExclusionsV1"}
    (out / "ml_exclusions.json").write_text(json.dumps(ml, indent=2), encoding="utf-8")

    # Cert-based exclusions
    cb = safe_call(api, "cbExclusionsGetV1")
    summary["artifacts"]["cert_exclusions"] = {"status": "ok" if cb["ok"] else "error", "operation": "cbExclusionsGetV1"}
    (out / "cert_exclusions.json").write_text(json.dumps(cb, indent=2), encoding="utf-8")

    # IOA exclusions (best effort)
    ioa = safe_call(api, "queryIOAExclusionsV1")
    summary["artifacts"]["ioa_exclusions"] = {"status": "ok" if ioa["ok"] else "error", "operation": "queryIOAExclusionsV1"}
    (out / "ioa_exclusions.json").write_text(json.dumps(ioa, indent=2), encoding="utf-8")

    # Scheduled reports inventory (best effort)
    sched = safe_call(api, "queryScheduledReports")
    if not sched["ok"]:
        sched = safe_call(api, "scheduledReportsQuery")
    summary["artifacts"]["scheduled_reports"] = {"status": "ok" if sched["ok"] else "error", "note": "If error, check scopes: Scheduled-reports:read"}
    (out / "scheduled_reports.json").write_text(json.dumps(sched, indent=2), encoding="utf-8")

    # Write summary + integrity manifest
    (out / "evidence_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

    manifest = {"generated_at": utc_now_iso(), "files": {}}
    for fp in out.glob("*.json"):
        manifest["files"][fp.name] = {"sha256": sha256_file(fp), "bytes": fp.stat().st_size}
    (out / "manifest_sha256.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")

    print("Evidence bundle created:", out)

if __name__ == "__main__":
    main()
