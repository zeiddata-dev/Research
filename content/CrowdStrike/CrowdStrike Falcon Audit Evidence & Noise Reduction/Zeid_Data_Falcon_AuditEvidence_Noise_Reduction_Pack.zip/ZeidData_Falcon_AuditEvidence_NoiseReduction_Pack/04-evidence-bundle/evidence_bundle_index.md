# Evidence Bundle Index (what to hand auditors)

## Bundle contents
- `rtr_audit_sessions.json` — RTR actions history (if available)
- `ml_exclusions.json` — ML exclusions inventory export
- `cert_exclusions.json` — certificate-based exclusions export
- `ioa_exclusions.json` — IOA exclusions export (best effort)
- `scheduled_reports.json` — scheduled reports export (best effort)
- `evidence_summary.json` — what was attempted/succeeded
- `manifest_sha256.json` — integrity hashes

## How to explain this bundle
- Exclusions show your allowlisting is tracked, approved, scoped, and reviewed.
- RTR audit shows incident actions were controlled and attributable.
- Scheduled reports show repeatable reporting and monitoring artifacts.
- Manifest proves bundle integrity after creation.
