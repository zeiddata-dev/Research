# Monthly evidence bundle runbook

## Objective
Produce a repeatable evidence set answering:
- Who changed security settings / exclusions?
- Who executed RTR sessions and what actions were taken?
- Are scheduled reports running, and what did they output?
- What is the current baseline of exclusions/policies?

## Cadence
- Monthly (default) + ad-hoc after major incidents

## Evidence artifacts (minimum)
- RTR audit sessions (last 30 days)
- ML exclusions inventory
- Certificate-based exclusions inventory
- IOA exclusions inventory (if enabled)
- Scheduled reports inventory + last executions (if enabled)
- Integrity manifest (SHA256)

## Storage
- Write to a controlled evidence share (read-only after creation)
- Retain per your policy (commonly 12–18 months)
