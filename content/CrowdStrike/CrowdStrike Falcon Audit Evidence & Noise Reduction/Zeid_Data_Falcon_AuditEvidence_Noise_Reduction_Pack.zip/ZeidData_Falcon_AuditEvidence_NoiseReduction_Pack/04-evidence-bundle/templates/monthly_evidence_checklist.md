# Monthly Evidence Checklist (copy into your ticket)

- [ ] Export RTR audit sessions (last 30 days)
- [ ] Export exclusions (ML / cert / IOA)
- [ ] Export scheduled reports + executions
- [ ] Export policy assignment baseline (optional, see notes)
- [ ] Generate manifest SHA256 and store with bundle
- [ ] Review exclusions expiring in next 30 days
- [ ] Document exceptions / renewals with approvals
