# LogScale evidence queries (examples)

These are high-level examples you can adapt to your schema.

## Detections by host group (last 30d)
- Count detections by `hostGroup` (or your enrichment field) and severity

## Top noisy detection patterns
- Group by `detectName` / `tactic` / `technique` and `sensorPlatform`

## Exclusion effectiveness
- Compare detections for excluded tool before/after exclusion date

> Adjust field names based on your ingestion / mapping.
