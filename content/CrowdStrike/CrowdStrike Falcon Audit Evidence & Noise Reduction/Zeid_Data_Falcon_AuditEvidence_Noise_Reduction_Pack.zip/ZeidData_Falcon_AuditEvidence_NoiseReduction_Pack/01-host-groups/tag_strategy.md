# Tag strategy (practical)

## Where to set tags
- Endpoint management (Intune, Jamf, SCCM, etc.)
- AD / identity attributes (export to your CMDB, then to Falcon via automation)
- Golden images (bake in “tier/env/team” where safe)

## Rules
- Prefer **small number** of high-signal tags over dozens of brittle ones.
- Avoid tags based on hostname regex unless you control naming strictly.
- Ensure every asset has at least: `zd_tier` and `zd_env`.

## Evidence
- Document tag sources (system-of-record)
- Monthly drift check (assets missing required tags)
