# Host group taxonomy (starter)

Design principle: **tune by tier and role, not by “everyone.”**

## Minimum recommended groups
- **Tier**
  - `TIER-DC` (domain controllers)
  - `TIER-SERVER-PROD`
  - `TIER-SERVER-NONPROD`
  - `TIER-WKS-PROD` (standard end-user fleet)
  - `TIER-WKS-DEV` (dev machines)
  - `TIER-BUILD` (CI/CD agents, build runners)
  - `TIER-VIP` (executives, privileged users)

- **Environment**
  - `ENV-PROD`, `ENV-STAGE`, `ENV-DEV`

- **Sensitivity**
  - `DATA-RESTRICTED`, `DATA-CONFIDENTIAL`, `DATA-INTERNAL`

## Tagging strategy (recommended)
Use tags you can set automatically:
- `zd_tier={dc|server|workstation|build|vip}`
- `zd_env={prod|stage|dev}`
- `zd_role={domain_controller|sql|app|citrix|...}`
- `zd_team={it|secops|data|...}`

## Evidence to keep (auditor-ready)
- Export of host groups + membership rules
- Export of policies + assignments per host group
- Exception list + approvals
