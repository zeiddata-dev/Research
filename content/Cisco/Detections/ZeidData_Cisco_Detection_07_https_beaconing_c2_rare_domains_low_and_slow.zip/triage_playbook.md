# Zeid Data — Cisco Detection Pack

## Triage playbook — HTTPS Beaconing / C2 to Rare Domains (Low-and-Slow)

1. Validate destination domain reputation and registration age (new domains are higher risk).
1. Check if the destination is associated with known SaaS used by the business.
1. Pull endpoint telemetry from the host to identify process making the connection.
1. If suspicious: block domain/IP, isolate host, and run a targeted hunt for persistence and credentials.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
