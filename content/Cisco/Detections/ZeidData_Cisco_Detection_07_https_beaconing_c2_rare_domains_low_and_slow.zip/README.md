# Zeid Data — Cisco Detection Pack

## HTTPS Beaconing / C2 to Rare Domains (Low-and-Slow)

**Primary Cisco products:** Cisco Secure Firewall, Cisco Umbrella, Cisco Secure Network Analytics (optional)  
    **Primary log sources:** FMC Connection Events (bytes/flows), Umbrella DNS Logs, Umbrella Security Events

    ## Why this detection exists
    Post-compromise command-and-control often appears as periodic outbound HTTPS sessions to rare domains or newly observed destinations. Pair DNS + flow patterns to reduce noise and catch 'quiet' beacons.

    ## Detection logic (high-level)
    - Identify outbound 443 connections with regular periodicity (e.g., every 60–300 seconds) from a host to a domain never seen in your environment (new domain for org in last 30 days).
- Prioritize where total bytes are small but persistent and destinations are rare across hosts (low prevalence).
- Escalate if DNS category indicates suspicious/newly seen or if IP reputation is malicious.

    ## Triage checklist
    - Validate destination domain reputation and registration age (new domains are higher risk).
- Check if the destination is associated with known SaaS used by the business.
- Pull endpoint telemetry from the host to identify process making the connection.
- If suspicious: block domain/IP, isolate host, and run a targeted hunt for persistence and credentials.

    ## Compliance mapping (common)
    - NIST 800-53: SI-4 (monitoring), SC-7 (boundary protection), AU-6.
- General detection engineering best practice: identify low-prevalence, persistent outbound comms.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
