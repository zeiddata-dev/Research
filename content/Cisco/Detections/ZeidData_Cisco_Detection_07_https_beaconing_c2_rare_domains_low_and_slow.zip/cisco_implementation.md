# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — HTTPS Beaconing / C2 to Rare Domains (Low-and-Slow)

- Enable TLS/SSL visibility where appropriate so SNI/domain is captured in connection logs.
- Export Umbrella DNS logs and correlate to see first-seen domains per org.
- Use Secure Network Analytics to add “rare destination / low prevalence” scoring if available.
