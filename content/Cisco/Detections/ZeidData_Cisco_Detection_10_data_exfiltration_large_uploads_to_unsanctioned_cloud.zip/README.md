# Zeid Data — Cisco Detection Pack

## Data Exfiltration: Large Uploads to Unsanctioned Cloud Storage (Firewall + Umbrella)

**Primary Cisco products:** Cisco Secure Firewall, Cisco Umbrella (SIG/proxy if available)  
    **Primary log sources:** FMC Connection Events (bytes), FMC File Events / URL Events (if enabled), Umbrella Proxy Logs / DNS Logs

    ## Why this detection exists
    Data theft commonly follows credential compromise and lateral movement. Monitoring large outbound transfers—especially to non-approved cloud storage—supports both incident response and compliance evidence requirements.

    ## Detection logic (high-level)
    - Detect large outbound bytes from a single host/user to cloud storage categories or known upload endpoints outside your approved list.
- Prioritize if transfer occurs outside business hours or from a workstation that rarely uploads large volumes.
- Escalate if combined with prior phishing/MFA anomalies or newly observed destinations.

    ## Triage checklist
    - Verify business justification (approved backup tools, sanctioned SaaS).
- Identify destination service and account context; check for OAuth tokens or SSO logs.
- If suspicious: block destination, isolate host, and preserve logs for legal/compliance review.
- Review DLP controls and strengthen allowlists.

    ## Compliance mapping (common)
    - NIST 800-53: AU-6 (audit review), SI-4, SC-7, MP-4 (media/storage handling where applicable).
- PCI DSS: Req 10 (monitor) and data protection expectations; HIPAA activity review requirements for ePHI systems.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
