# Zeid Data — Cisco Detection Pack

## Triage playbook — Data Exfiltration: Large Uploads to Unsanctioned Cloud Storage (Firewall + Umbrella)

1. Verify business justification (approved backup tools, sanctioned SaaS).
1. Identify destination service and account context; check for OAuth tokens or SSO logs.
1. If suspicious: block destination, isolate host, and preserve logs for legal/compliance review.
1. Review DLP controls and strengthen allowlists.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
