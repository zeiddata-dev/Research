# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Data Exfiltration: Large Uploads to Unsanctioned Cloud Storage (Firewall + Umbrella)

- Enable byte counters in Secure Firewall connection logs; enable URL/File logging where appropriate.
- If using Umbrella SIG/proxy, ingest proxy logs for URL categorization and upload indicators.
- Maintain an approved cloud storage allowlist and alert on everything else by default for sensitive networks.
