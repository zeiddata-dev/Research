# Zeid Data — Cisco Detection Pack

## Suspicious Perimeter Remote Admin Access (VPN/SSH/RDP) — New Source + High Velocity

**Primary Cisco products:** Cisco Secure Firewall (AnyConnect/RA-VPN), Cisco Duo (if used for MFA), Cisco Secure Network Analytics (optional)  
    **Primary log sources:** FMC Remote Access VPN Events (if AnyConnect), FMC Connection Events, Duo Authentication Logs (optional)

    ## Why this detection exists
    Credential abuse and remote access misuse are common precursors to ransomware and data theft. Detect first-time (or rare) source IPs for privileged access and pair that with abnormal session volume or lateral movement indicators.

    ## Detection logic (high-level)
    - Detect successful VPN logins for privileged users from a source IP not seen for that user in the last 30 days.
- OR detect successful SSH/RDP to admin segments from a source IP not in an approved management range.
- Increase priority if followed by: multiple new internal connections, high volume of authentication attempts, or access to sensitive subnets.

    ## Triage checklist
    - Verify user legitimacy (out-of-band) and confirm expected travel/location and device posture.
- Review VPN session details (client, OS, geo/IP reputation if available, auth method).
- Look for follow-on internal scanning or admin tool usage from the VPN-assigned IP.
- If suspicious: terminate session, reset credentials, rotate keys, and review privileged access policies.

    ## Compliance mapping (common)
    - NIST 800-53: AC-2/AC-6 (Account Management/Least Privilege), IA-2 (Identification & Authentication), AU-12 (Audit Generation), SI-4.
- PCI DSS: Req 7/8 (access control, identify/authenticate), Req 10 (log/monitor).

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
