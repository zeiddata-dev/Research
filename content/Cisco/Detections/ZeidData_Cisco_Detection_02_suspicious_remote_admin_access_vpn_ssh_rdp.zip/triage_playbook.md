# Zeid Data — Cisco Detection Pack

## Triage playbook — Suspicious Perimeter Remote Admin Access (VPN/SSH/RDP) — New Source + High Velocity

1. Verify user legitimacy (out-of-band) and confirm expected travel/location and device posture.
1. Review VPN session details (client, OS, geo/IP reputation if available, auth method).
1. Look for follow-on internal scanning or admin tool usage from the VPN-assigned IP.
1. If suspicious: terminate session, reset credentials, rotate keys, and review privileged access policies.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
