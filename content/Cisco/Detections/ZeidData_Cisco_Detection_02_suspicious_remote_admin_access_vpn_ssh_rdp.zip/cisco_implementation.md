# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Suspicious Perimeter Remote Admin Access (VPN/SSH/RDP) — New Source + High Velocity

- Forward Remote Access VPN logs and Connection Events to SIEM.
- Maintain an allowlist of management IP ranges and privileged user groups.
- If using Duo, ingest auth logs and correlate MFA risk events with VPN success.
