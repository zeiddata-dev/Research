# Zeid Data — Cisco Detection Pack

## Ransomware Staging / Pre-Encryption Behavior (Secure Endpoint)

**Primary Cisco products:** Cisco Secure Endpoint (AMP)  
    **Primary log sources:** Secure Endpoint Detections, Secure Endpoint Device Trajectory / Events

    ## Why this detection exists
    Talos reporting emphasizes 'pre-ransomware' detection opportunities: credential abuse, disabling defenses, and staging behaviors often precede encryption. Endpoint telemetry can catch these behaviors before files are impacted.

    ## Detection logic (high-level)
    - Alert on Secure Endpoint detections for ransomware-like behavior or suspicious mass file modifications.
- Alert on common pre-encryption actions: shadow copy deletion attempts, backup/restore tampering, security tool disable attempts (as detected by endpoint controls).
- Escalate if combined with recent lateral movement signals or suspicious VPN logins.

    ## Triage checklist
    - Isolate endpoint via Secure Endpoint; capture trajectory details (parent/child processes, hash, user).
- Check for credential dumping indicators, scheduled tasks, new services, persistence.
- Coordinate with IT for account resets and forensics capture if needed.
- Block hashes/domains across security stack if confirmed.

    ## Compliance mapping (common)
    - NIST 800-53: SI-3 (Malicious Code Protection), SI-4, IR-4.
- Many programs require malware detection and response capability.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
