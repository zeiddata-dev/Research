# Zeid Data — Cisco Detection Pack

## East-West Recon: Internal Scanning & Lateral Movement (NetFlow/SNA)

**Primary Cisco products:** Cisco Secure Network Analytics (Stealthwatch), Cisco Secure Firewall (internal sensors, optional)  
    **Primary log sources:** NetFlow/IPFIX from core, SNA Alarms/Events, FMC Connection Events (if inspecting east-west)

    ## Why this detection exists
    After initial access, attackers commonly scan for file shares, RDP/SMB targets, and management interfaces. Catching east-west reconnaissance early can stop ransomware chains before encryption.

    ## Detection logic (high-level)
    - Detect a single internal host connecting to many internal destinations over common admin ports (445, 3389, 5985/5986, 135, 22) within a short window.
- Prioritize if success rate is low (many fails) and the host is not a known scanner/jump box.
- Escalate if scanning is followed by successful admin access to multiple hosts or unusual authentication spikes.

    ## Triage checklist
    - Validate whether the source is an approved scanner or management platform.
- Identify targeted subnets/hosts; check for sensitive segments being probed.
- If suspicious: isolate source host, review credentials used, and check for malware tooling on the source.
- Hunt for similar patterns from other hosts (potential worming).

    ## Compliance mapping (common)
    - NIST 800-53: SI-4, SC-7, AC-6.
- Supports segmentation/monitoring expectations in many regulatory programs.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
