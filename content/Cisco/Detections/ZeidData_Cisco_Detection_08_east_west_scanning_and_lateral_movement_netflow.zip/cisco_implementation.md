# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — East-West Recon: Internal Scanning & Lateral Movement (NetFlow/SNA)

- Ensure NetFlow/IPFIX export from core/distribution is enabled and ingested.
- In SNA, tune thresholds to your baseline and exclude known scanners/jump hosts.
- If you inspect east-west with Secure Firewall, forward those connection events too.
