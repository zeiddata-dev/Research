# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Internet-Facing Exploitation Attempt (KEV-Prioritized)

- Ensure Intrusion Events are enabled and forwarded (eStreamer recommended) to your SIEM.
- Maintain a watchlist of KEV-prioritized CVEs/signatures (update weekly).
- Tag DMZ/public assets (VIPs, published apps) so you can scope detections to high-value exposure.
