# Zeid Data — Cisco Detection Pack

## Triage playbook — Internet-Facing Exploitation Attempt (KEV-Prioritized)

1. Confirm destination asset ownership, exposure, and patch level; check if the CVE is applicable.
1. Review intrusion event details: signature, impact, decoded payload fields (if present), and packet capture if available.
1. Check connection logs for successful sessions or unusual POST/UPLOAD patterns immediately after the alert.
1. Search for additional activity from the same source IP across other perimeter services.
1. If confirmed: block source at edge, apply virtual patching (IPS), and prioritize remediation for the vulnerable service.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
