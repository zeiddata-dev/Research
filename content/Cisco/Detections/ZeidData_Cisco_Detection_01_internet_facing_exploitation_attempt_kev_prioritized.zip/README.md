# Zeid Data — Cisco Detection Pack

## Internet-Facing Exploitation Attempt (KEV-Prioritized)

**Primary Cisco products:** Cisco Secure Firewall (FTD/FMC), Cisco Secure Network Analytics (optional)  
    **Primary log sources:** FMC Intrusion Events, FMC Connection Events, FMC Security Intelligence Events (if enabled)

    ## Why this detection exists
    Vulnerability exploitation of public-facing services remains a dominant initial access path in recent incident response reporting. Prioritize alerts tied to CISA’s Known Exploited Vulnerabilities (KEV) list so patch/mitigation work aligns to active exploitation.

    ## Detection logic (high-level)
    - Trigger on FMC Intrusion Events with high severity (e.g., High/Critical) OR high confidence signatures.
- Destination is an internet-facing asset (DMZ / public VIP / published service).
- Signature/category matches web app/server exploitation or maps to a KEV-tracked CVE (maintained as a watchlist).
- Optionally: correlate with connection events showing successful follow-on sessions from same source to same destination within 10 minutes.

    ## Triage checklist
    - Confirm destination asset ownership, exposure, and patch level; check if the CVE is applicable.
- Review intrusion event details: signature, impact, decoded payload fields (if present), and packet capture if available.
- Check connection logs for successful sessions or unusual POST/UPLOAD patterns immediately after the alert.
- Search for additional activity from the same source IP across other perimeter services.
- If confirmed: block source at edge, apply virtual patching (IPS), and prioritize remediation for the vulnerable service.

    ## Compliance mapping (common)
    - NIST 800-53: SI-4 (System Monitoring), RA-5 (Vulnerability Monitoring), SC-7 (Boundary Protection), AU-6 (Audit Review).
- PCI DSS: Req 6 (secure systems & applications), Req 10 (log/monitor), Req 11 (testing).
- HIPAA Security Rule: 164.308(a)(1)(ii)(D) Information system activity review.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
