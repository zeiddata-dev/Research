# Zeid Data — Cisco Detection Pack

## Duo MFA Fatigue / Fraudulent Push / High-Risk Authentication

**Primary Cisco products:** Cisco Duo  
    **Primary log sources:** Duo Authentication Logs, Duo Admin Logs (optional)

    ## Why this detection exists
    Phishing and credential theft remain prevalent, and attackers often pressure users with repeated push prompts (“MFA fatigue”) or attempt logins from new devices/locations. Duo provides risk signals and user-reported fraudulent pushes that are high-fidelity detections.

    ## Detection logic (high-level)
    - Alert when a user marks a Duo push as fraudulent.
- Alert on repeated push requests for the same user within a short window (e.g., 10+ prompts in 10 minutes).
- Alert on high-risk auth flagged by risk-based policies (new device + unusual location + impossible travel).
- Escalate if followed by a successful authentication from a new device/source shortly after multiple denies.

    ## Triage checklist
    - Contact user and confirm whether they initiated authentication.
- Check target application and device details; confirm if the device is enrolled/managed.
- If suspicious: disable the user’s sessions/tokens, reset password, and review conditional access/MFA enrollment.
- Search for additional auth attempts across IdP/VPN and for mailbox rules/OAuth grants if applicable.

    ## Compliance mapping (common)
    - NIST 800-53: IA-2 (MFA), AC-7 (Unsuccessful Logon Attempts), AU-6 (Audit Review), IR-4 (Incident Handling).
- PCI DSS: Req 8 (identify/authenticate).

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
