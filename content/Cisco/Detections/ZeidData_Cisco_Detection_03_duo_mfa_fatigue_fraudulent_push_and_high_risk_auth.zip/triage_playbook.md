# Zeid Data — Cisco Detection Pack

## Triage playbook — Duo MFA Fatigue / Fraudulent Push / High-Risk Authentication

1. Contact user and confirm whether they initiated authentication.
1. Check target application and device details; confirm if the device is enrolled/managed.
1. If suspicious: disable the user’s sessions/tokens, reset password, and review conditional access/MFA enrollment.
1. Search for additional auth attempts across IdP/VPN and for mailbox rules/OAuth grants if applicable.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
