# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Duo MFA Fatigue / Fraudulent Push / High-Risk Authentication

- Enable and retain Duo Authentication logs; forward to SIEM via API/collector.
- Turn on Duo Risk-Based Authentication / policies appropriate for your org.
- Create an escalation path for any 'fraudulent push' events (these should be treated as high-priority).
