# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Encrypted DNS Bypass (DoH/DoT) / Third-Party Resolver Use

- On Secure Firewall: create an ACP rule to block outbound 853 except to approved resolvers; monitor hit counts.
- On Umbrella: ensure endpoints are configured to use Umbrella / enterprise DNS (roaming client helps off-network).
- On endpoints: manage browser DoH settings via policy (GPO/MDM) and document exceptions.
