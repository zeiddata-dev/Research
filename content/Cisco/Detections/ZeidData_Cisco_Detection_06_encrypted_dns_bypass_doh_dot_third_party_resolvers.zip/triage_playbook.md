# Zeid Data — Cisco Detection Pack

## Triage playbook — Encrypted DNS Bypass (DoH/DoT) / Third-Party Resolver Use

1. Identify the host/application generating DoH/DoT (browsers often have DoH toggles).
1. Determine if the behavior is approved (some security tools may use specialized resolvers).
1. If unapproved: enforce endpoint/browser policy, block at firewall, and re-test with the business owner.
1. Verify DNS architecture aligns with your org’s policy (centralized, logged, and protected).

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
