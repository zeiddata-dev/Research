# Zeid Data — Cisco Detection Pack

## Encrypted DNS Bypass (DoH/DoT) / Third-Party Resolver Use

**Primary Cisco products:** Cisco Secure Firewall, Cisco Umbrella  
    **Primary log sources:** FMC Connection Events, Umbrella DNS Logs (to confirm resolver usage), Web Proxy Logs (if Umbrella SIG is used)

    ## Why this detection exists
    Compliance and security programs increasingly require controlling DNS resolution paths (protective DNS, encrypted DNS) and preventing endpoints/apps from bypassing enterprise resolvers via third-party DoH/DoT. Detect and block unauthorized resolver traffic and DoH patterns.

    ## Detection logic (high-level)
    - Detect outbound connections to known public DoH resolver IPs/domains or known DoH endpoints (HTTP/2 over 443 with DoH paths where visible).
- Detect outbound TCP/UDP 853 (DoT) to the internet that is not your approved upstream resolver.
- Detect clients generating DNS traffic that is not observed in Umbrella logs (suggesting bypass via local resolver or encrypted DNS direct-to-internet).

    ## Triage checklist
    - Identify the host/application generating DoH/DoT (browsers often have DoH toggles).
- Determine if the behavior is approved (some security tools may use specialized resolvers).
- If unapproved: enforce endpoint/browser policy, block at firewall, and re-test with the business owner.
- Verify DNS architecture aligns with your org’s policy (centralized, logged, and protected).

    ## Compliance mapping (common)
    - NIST 800-53: SC-7, SC-20/SC-21, SI-4.
- This aligns with guidance encouraging controlled DNS infrastructure and preventing direct third‑party resolver use.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
