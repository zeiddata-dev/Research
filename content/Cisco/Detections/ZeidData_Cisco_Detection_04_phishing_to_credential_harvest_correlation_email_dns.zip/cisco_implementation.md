# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — Phishing → Credential Harvest Correlation (Secure Email + Umbrella)

- Enable SEG message tracking and verdict logging; normalize recipient fields.
- Send Umbrella DNS and Security Events to the SIEM.
- Maintain a lookalike/newly-registered domain policy in Umbrella where feasible.
