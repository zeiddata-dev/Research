# Zeid Data — Cisco Detection Pack

## Triage playbook — Phishing → Credential Harvest Correlation (Secure Email + Umbrella)

1. Identify all recipients; confirm who clicked.
1. Block domain/URL across Umbrella and email controls; retroactively remove similar emails if supported.
1. Reset user credentials and review MFA enrollment if click/credential submission suspected.
1. Hunt for follow-on activity: OAuth grants, mailbox rules, external forwarding, anomalous logins.

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
