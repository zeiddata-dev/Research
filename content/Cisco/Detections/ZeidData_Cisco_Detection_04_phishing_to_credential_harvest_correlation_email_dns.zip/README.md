# Zeid Data — Cisco Detection Pack

## Phishing → Credential Harvest Correlation (Secure Email + Umbrella)

**Primary Cisco products:** Cisco Secure Email, Cisco Umbrella  
    **Primary log sources:** Secure Email Gateway (SEG) Message Tracking / Verdicts, Umbrella DNS Logs, Umbrella Security Events

    ## Why this detection exists
    Recent incident response reporting continues to show phishing as a leading initial access vector. Correlating email verdicts with subsequent DNS access to newly seen/phishing domains increases confidence and speeds response.

    ## Detection logic (high-level)
    - Detect inbound email classified as phishing/impersonation or containing suspicious URLs/attachments.
- Within 60 minutes, the recipient device/user performs DNS lookups or HTTP requests to the same domain (or newly registered lookalike domains).
- Escalate if followed by IdP/VPN auth anomalies (new device, new geo, impossible travel) or mailbox rule changes.

    ## Triage checklist
    - Identify all recipients; confirm who clicked.
- Block domain/URL across Umbrella and email controls; retroactively remove similar emails if supported.
- Reset user credentials and review MFA enrollment if click/credential submission suspected.
- Hunt for follow-on activity: OAuth grants, mailbox rules, external forwarding, anomalous logins.

    ## Compliance mapping (common)
    - NIST 800-53: SI-4, AT-2 (Awareness Training), IR-4, AC-2.
- PCI DSS: Req 10 (monitor), Req 12 (security awareness).

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
