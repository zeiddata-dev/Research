# Zeid Data — Cisco Detection Pack

## DNS Tunneling / DNS Exfiltration (Umbrella)

**Primary Cisco products:** Cisco Umbrella  
    **Primary log sources:** Umbrella Security Events, Umbrella DNS Logs

    ## Why this detection exists
    DNS tunneling/exfiltration is a well-known technique for covert command-and-control and data theft. Umbrella includes DNS tunneling/exfiltration detections and NIST guidance highlights DNS as a key control plane to monitor and harden.

    ## Detection logic (high-level)
    - Alert on Umbrella events categorized as DNS tunneling or DNS exfiltration.
- Supplement with heuristics: high query volume to a single domain, unusually long/high-entropy subdomains, elevated TXT queries, high NXDOMAIN rates to a domain.
- Escalate if the client also shows outbound HTTPS to the same domain/IP or if endpoint telemetry shows suspicious processes.

    ## Triage checklist
    - Identify the client host/user and associated process (if available via endpoint integration).
- Check if the domain is sanctioned (rare for legitimate apps to tunnel at scale).
- Block the domain and isolate host if confirmed malicious; collect triage artifacts (process list, persistence checks).
- Validate resolver configuration (ensure clients use enterprise DNS, not bypassing).

    ## Compliance mapping (common)
    - NIST 800-53: SC-7 (Boundary Protection), SI-4 (System Monitoring), SC-20/SC-21 (Secure Name/Address Resolution).
- General best practice: centralized DNS logging and protective DNS controls.

    ## Tuning notes
    - Start in **monitor-only** mode for 7–14 days to establish baseline.
    - Exclude known scanners/backup tools/management ranges.
    - Add an escalation rule when multiple detections correlate to the same host/user within 24 hours.

    ---
    **Assumptions**
- You forward Cisco product telemetry (syslog/eStreamer/API) into your SIEM.
- Field names vary by environment; the provided queries are *skeletons* meant to be adapted.
- Tune thresholds to your baseline to avoid noisy alerts.

**What’s included**
- `README.md` — human-readable guidance
- `detection.yaml` — structured detection metadata (name, severity, sources, logic)
- `siem/splunk.spl` — starter Splunk analytic (optional)
- `cisco_implementation.md` — where/what to enable in Cisco products
- `triage_playbook.md` — quick response checklist
