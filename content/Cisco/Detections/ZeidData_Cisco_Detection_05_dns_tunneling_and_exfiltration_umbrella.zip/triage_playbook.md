# Zeid Data — Cisco Detection Pack

## Triage playbook — DNS Tunneling / DNS Exfiltration (Umbrella)

1. Identify the client host/user and associated process (if available via endpoint integration).
1. Check if the domain is sanctioned (rare for legitimate apps to tunnel at scale).
1. Block the domain and isolate host if confirmed malicious; collect triage artifacts (process list, persistence checks).
1. Validate resolver configuration (ensure clients use enterprise DNS, not bypassing).

### Evidence to preserve
- Relevant Cisco event logs (raw + parsed) for the time window
- Asset identity details (host, user, IP, VLAN/subnet, device ID)
- Related email/auth/endpoint events (if applicable)
- Firewall rule hits / URL categories / intrusion signature metadata

### Closure criteria
- Root cause identified (benign vs malicious)
- Containment applied if malicious (block/isolate/terminate sessions)
- Remediation ticket created (patch, config change, user coaching)
- Detection tuned (exceptions/threshold adjustments) after lessons learned
