# Zeid Data — Cisco Detection Pack

## Cisco implementation notes — DNS Tunneling / DNS Exfiltration (Umbrella)

- Enable Umbrella Security Events export (including DNS tunneling/exfil signals).
- Ensure roaming clients / network devices use Umbrella resolvers or forwarding paths.
- Set automatic blocking policies for confirmed tunneling domains and create an exception workflow.
