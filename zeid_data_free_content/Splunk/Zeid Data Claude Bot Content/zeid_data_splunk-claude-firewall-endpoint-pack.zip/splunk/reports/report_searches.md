# Reports — Firewall + Endpoint

Recommended scheduled reports:
1) Daily summary: top endpoints/users/processes + firewall top sources/dests
2) High severity: server assets contacting api.anthropic.com (and firewall allowed)
3) New process: first-seen process initiating Claude/Anthropic DNS in 30d baseline

Export:
- schedule CSV/PDF
- optionally write results to a summary index for long-term trends
