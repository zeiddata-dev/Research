# Scheduled hunts / reports

A) Near-real-time alert (10–15m):
- any DomainName matching *claude.ai or *anthropic.com
- include ComputerName, UserName, ContextBaseFileName, ContextCommandLine

B) Daily summary:
- top endpoints/users/processes
- split web (claude.ai) vs API (api.anthropic.com)

C) High severity:
- server-class assets contacting api.anthropic.com
