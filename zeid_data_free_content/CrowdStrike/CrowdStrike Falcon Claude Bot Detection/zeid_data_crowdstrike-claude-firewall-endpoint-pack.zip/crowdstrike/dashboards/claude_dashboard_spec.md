# Falcon Dashboard spec (Endpoint-focused, firewall-correlation ready)

Widgets:
1) Trend (7d): DNS requests where DomainName matches *claude.ai OR *anthropic.com
2) Top endpoints: ComputerName
3) Top users: UserName
4) Top initiating processes: ContextBaseFileName
5) Likely API usage: DomainName=api.anthropic.com AND process NOT in browser list

Report exports:
- Daily CSV of widgets 2–5
- Weekly summary: top endpoints + top processes

Correlation guidance:
- Correlate with firewall in SIEM using src host identity + time window.
