# evidence checklist
    **platform:** Splunk

    ## required fields to capture (as available)
    - [ ] _time
- [ ] index
- [ ] sourcetype
- [ ] host
- [ ] source
- [ ] src
- [ ] dest
- [ ] user
- [ ] signature/rule_name
- [ ] notable_id (if ES)
- [ ] urgency/severity
- [ ] action
- [ ] bytes_in/bytes_out
- [ ] app
- [ ] vendor_product
- [ ] search_name
- [ ] risk_score
- [ ] ticket_id
- [ ] drilldown_search

    ## chain-of-custody (mini form)
    - **collected by:** [name]
    - **collection time (utc):** [yyyy-mm-dd hh:mm]
    - **source system:** Splunk ([console/workspace/index])
    - **export format:** [csv/json/pdf/screenshot]
    - **stored at:** [evidence_repo_path]
    - **integrity (optional):** sha256([filename]) = [hash]

    ## export guidance (high level)
    - export only the minimum necessary [time_range] and entities (user/device/account) to reduce noise.
- prefer raw event exports (json/csv) + a screenshot of filters/time range used.
- record the query/search text (or saved search name) used to generate the export.
- store artifacts in [evidence_repo_path] with consistent naming: [incident_id]_[source]_[utc_range].
- include the exact spl used and the saved search/correlation name (if es).
