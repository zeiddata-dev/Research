# communications templates
**platform:** Splunk

## internal soc update
**subject:** [incident_id] [severity] Splunk — triage update  
**body:**  
- what we saw: [1–2 lines]  
- scope so far: [users/devices/accounts]  
- actions taken: [containment actions + approvals]  
- next steps: [next steps]  
- evidence: [links]

## leadership update
**subject:** [incident_id] [severity] executive summary  
**body:**  
- status: [open/contained/recovering]  
- impact: [none/unknown/confirmed] — [1 line]  
- what we are doing: [1–2 lines]  
- decisions needed: [approvals required]  
- next update: [utc time]

## affected team/user notification
**subject:** security notice — action required ([incident_id])  
**body:**  
- we detected: [high-level description]  
- what you need to do: [password reset / mfa re-enroll / device check]  
- what to expect: [potential disruption]  
- contact: [soc contact]

## vendor support case opener
**subject:** support request — [incident_id] Splunk investigation  
**body:**  
- environment: [cloud/on-prem], [region], [tenant/org]  
- time range (utc): [time_range]  
- symptoms: [what you see]  
- artifacts: [exports/screenshots]  
- questions: [what you need from vendor]

## what not to say (quick guardrails)
- don’t speculate about root cause or attribution without evidence.
- don’t share sensitive indicators externally without approval.
- don’t promise timelines you can’t support; commit to the next update time instead.
