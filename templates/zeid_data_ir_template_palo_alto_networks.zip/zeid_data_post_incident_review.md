# post-incident review (pir)
    **platform:** Palo Alto Networks

    ## root cause prompts
    - [ ] what was the initial detection source and why did it fire?
- [ ] what was the true root cause (technical + process)?
- [ ] what evidence proves containment and recovery?
- [ ] what controls failed or were missing (logging, policy, segmentation, iam)?
- [ ] what could we automate or standardize to reduce time to contain?

    ## detection gap analysis
    - what did we miss initially? [logging / correlation / thresholds]
    - what false positives did we see? [top 3]
    - what tuning is required? [rule/policy] — approval: [approval] — ticket: [id]

    ## preventive actions
    - controls: [policy change / block / mfa / segmentation]
    - visibility: [enable log source / increase retention]
    - process: [runbook update / training / on-call change]

    ## metrics
    - mttd: [minutes/hours]
- mttr: [minutes/hours/days]
- # affected users: [n]
- # affected devices: [n]
- data exposure: [yes/no/unknown]
- customer impact: [yes/no]

    ## follow-up tasks
    | task | owner | due date | tracking id | evidence of completion |
    |---|---|---|---|---|
    | [task] | [name] | [yyyy-mm-dd] | [id] | [link] |
