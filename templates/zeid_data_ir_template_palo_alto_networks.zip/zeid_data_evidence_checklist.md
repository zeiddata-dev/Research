# evidence checklist
    **platform:** Palo Alto Networks

    ## required fields to capture (as available)
    - [ ] receive_time
- [ ] serial
- [ ] vsys
- [ ] src_ip
- [ ] src_port
- [ ] dst_ip
- [ ] dst_port
- [ ] app
- [ ] rule_name
- [ ] action
- [ ] threat_id
- [ ] threat_name
- [ ] severity
- [ ] url
- [ ] url_category
- [ ] user
- [ ] device_name (if available)
- [ ] bytes
- [ ] session_id
- [ ] nat_src/nat_dst (if used)
- [ ] zone_in/zone_out

    ## chain-of-custody (mini form)
    - **collected by:** [name]
    - **collection time (utc):** [yyyy-mm-dd hh:mm]
    - **source system:** Palo Alto Networks ([console/workspace/index])
    - **export format:** [csv/json/pdf/screenshot]
    - **stored at:** [evidence_repo_path]
    - **integrity (optional):** sha256([filename]) = [hash]

    ## export guidance (high level)
    - export only the minimum necessary [time_range] and entities (user/device/account) to reduce noise.
- prefer raw event exports (json/csv) + a screenshot of filters/time range used.
- record the query/search text (or saved search name) used to generate the export.
- store artifacts in [evidence_repo_path] with consistent naming: [incident_id]_[source]_[utc_range].
