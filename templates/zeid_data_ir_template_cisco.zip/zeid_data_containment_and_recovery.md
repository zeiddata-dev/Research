# containment and recovery
    **platform:** Cisco

    ## containment options (choose what’s appropriate + approved)
    - [ ] Umbrella: block domain/category, add destination to block list, apply policy to identity group
- [ ] Firewall: add temporary block rule (IP/domain), tighten egress, enable/raise IPS action
- [ ] Secure Endpoint: isolate/contain endpoint (if available), quarantine file, block hash
- [ ] Network: move host to quarantine VLAN / NAC policy, disable switchport (approved only)

    ## risk notes
    - confirm [business_owner] approval for actions that impact production access.
    - prefer **least disruptive** controls first (block ioc, isolate single host, narrow policy changes).
    - watch for attacker adaptation (domain rotation, new credentials, new endpoints).

    ## rollback plan (must be written before changes)
    - [ ] document every change with: who, what, when, why, approval, and rollback steps.
- [ ] use time-bounded controls where possible (temporary blocks with expiry).
- [ ] avoid destructive actions unless approved and necessary for safety (e.g., account disable).

    ## recovery validation checklist
    - [ ] validate alerts stop for the original indicator(s) across [time_range_after].
- [ ] confirm business services restored (owner sign-off).
- [ ] re-enable any temporary restrictions only after validation and approval.
- [ ] capture final evidence showing containment success (before/after exports).
