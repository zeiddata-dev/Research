# containment and recovery
    **platform:** CrowdStrike

    ## containment options (choose what’s appropriate + approved)
    - [ ] Network Containment (isolate host) (approved)
- [ ] Kill process / quarantine file (validated), block hash
- [ ] Add IOC (domain/IP/hash) to prevent policy
- [ ] Reset credentials / invalidate sessions for affected user (coordinated with IAM)
- [ ] RTR: collect triage artifacts (logs) (per policy)

    ## risk notes
    - confirm [business_owner] approval for actions that impact production access.
    - prefer **least disruptive** controls first (block ioc, isolate single host, narrow policy changes).
    - watch for attacker adaptation (domain rotation, new credentials, new endpoints).

    ## rollback plan (must be written before changes)
    - [ ] document every change with: who, what, when, why, approval, and rollback steps.
- [ ] use time-bounded controls where possible (temporary blocks with expiry).
- [ ] avoid destructive actions unless approved and necessary for safety (e.g., account disable).

    ## recovery validation checklist
    - [ ] validate alerts stop for the original indicator(s) across [time_range_after].
- [ ] confirm business services restored (owner sign-off).
- [ ] re-enable any temporary restrictions only after validation and approval.
- [ ] capture final evidence showing containment success (before/after exports).
