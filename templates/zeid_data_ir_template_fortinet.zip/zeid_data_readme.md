# incident response template pack
    **platform:** Fortinet

    this pack provides short, copy/paste ir templates for soc use. it is designed to capture **evidence**, **decisions**, and **approvals** in a consistent way.

    ## when to use
    - alerts or incidents where Fortinet telemetry or controls are part of detection/response
    - any situation requiring audit-ready documentation (what happened, what you did, and why)

    ## quick start (3–5 steps)
    1) create a new case/ticket using `zeid_data_ir_template.md` and fill in the header.
    2) run `zeid_data_triage_checklist.md` for fast confirmation + scope.
    3) collect required artifacts using `zeid_data_evidence_checklist.md` and attach exports/screenshots.
    4) execute approved actions from `zeid_data_containment_and_recovery.md`.
    5) send updates using `zeid_data_communications.md` and close with `zeid_data_post_incident_review.md`.

    ## required inputs
    - [incident_id], [severity], [time_range], [owner], [environment], [business_impact]
    - affected: [user], [device], [asset], [account], [app], [network_segment]

    ## evidence rule
    **if it didn’t generate evidence, it didn’t happen.**  
    every claim should be backed by an export, screenshot, log excerpt, or query result.

    ## typical telemetry for this platform
    - FortiGate traffic logs (forward, local, UTM events)
- UTM logs: Web Filter, Application Control, IPS, AntiVirus, DNS Filter (if enabled)
- FortiAnalyzer (aggregated logging/reporting) (if used)
- FortiManager change/audit logs (if used)
- VPN logs (SSL VPN / IPsec) (user, src, device)
