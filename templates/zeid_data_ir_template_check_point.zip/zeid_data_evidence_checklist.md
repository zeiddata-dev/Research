# evidence checklist
    **platform:** Check Point

    ## required fields to capture (as available)
    - [ ] time
- [ ] log_uid
- [ ] gateway
- [ ] src
- [ ] dst
- [ ] service
- [ ] proto
- [ ] action
- [ ] rule_name
- [ ] layer_name
- [ ] blade
- [ ] severity
- [ ] confidence
- [ ] app
- [ ] category
- [ ] url
- [ ] user
- [ ] client_ip
- [ ] bytes
- [ ] session_id (if available)
- [ ] nat_src/nat_dst (if used)

    ## chain-of-custody (mini form)
    - **collected by:** [name]
    - **collection time (utc):** [yyyy-mm-dd hh:mm]
    - **source system:** Check Point ([console/workspace/index])
    - **export format:** [csv/json/pdf/screenshot]
    - **stored at:** [evidence_repo_path]
    - **integrity (optional):** sha256([filename]) = [hash]

    ## export guidance (high level)
    - export only the minimum necessary [time_range] and entities (user/device/account) to reduce noise.
- prefer raw event exports (json/csv) + a screenshot of filters/time range used.
- record the query/search text (or saved search name) used to generate the export.
- store artifacts in [evidence_repo_path] with consistent naming: [incident_id]_[source]_[utc_range].
