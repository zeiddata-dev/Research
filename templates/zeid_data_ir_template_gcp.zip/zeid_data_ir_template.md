# incident report template
    **platform:** Google Cloud (GCP)

    ## 1) incident header
    - **incident id:** [incident_id]
    - **title:** [title]
    - **severity:** [severity] (low/medium/high/critical)
    - **status:** [status] (open/triage/contained/eradication/recovery/closed)
    - **owner:** [owner]
    - **start time (utc):** [start_utc]
    - **end time (utc):** [end_utc]
    - **time range investigated:** [time_range]
    - **environment:** [environment] (prod/dev/lab)
    - **business impact (1–2 lines):** [business_impact]
**cloud identifiers:** [PROJECT_ID], [ORGANIZATION_ID], [FOLDER_ID], [PRINCIPAL_EMAIL], [CALLER_IP], [REGION]


    ## 2) scope
    - **users/identities:** [user_list]
    - **devices/hosts:** [device_list]
    - **accounts/tenants/orgs:** [account_list]
    - **apps/services:** [app_list]
    - **networks/zones/vpc/vnet:** [network_scope]
    - **related alerts/findings:** [alert_ids]

    ## 3) timeline (fill as you go)
    | time (utc) | source | event | notes | evidence |
    |---|---|---|---|---|
    | [yyyy-mm-dd hh:mm] | Google Cloud (GCP) | [what happened] | [why it matters] | [link/attachment] |

    ## 4) hypothesis + findings
    - **working hypothesis:** [one sentence]
    - **confirmed facts (with evidence):**
      - [fact_1] — evidence: [link/attachment]
      - [fact_2] — evidence: [link/attachment]
    - **open questions:**
      - [question_1]
      - [question_2]

    ## 5) decisions + approvals log
    | time (utc) | decision | reason | approved by | ticket/change id | evidence |
    |---|---|---|---|---|---|
    | [yyyy-mm-dd hh:mm] | [action/decision] | [rationale] | [approval] | [id] | [link] |

    ## 6) indicators (iocs/ioas)
    - **domains/hosts:** [domains]
    - **ips:** [ips]
    - **urls:** [urls]
    - **file hashes (if applicable):** [sha256]
    - **rules/signatures/detections:** [rules_or_detections]

    ## 7) impact + data exposure (high level)
    - **systems impacted:** [systems]
    - **data impacted:** [data_types] (none/unknown/confirmed)
    - **exposure assessment:** [yes/no/unknown]  
      notes: [short justification + evidence links]

    ## 8) attachments
    - exports: [export_links]
    - screenshots: [screenshot_links]
    - queries/searches: [query_text_or_links]
    - other: [other_artifacts]
