# triage checklist
    **platform:** Google Cloud (GCP)

    ## fast checks (15 minutes)
    - [ ] confirm alert/finding authenticity and timestamp accuracy
- [ ] identify primary entity: [user] / [device] / [account] / [ip] / [domain]
- [ ] validate source telemetry present for [time_range] (no logging gaps)
- [ ] confirm whether action was allowed vs blocked vs prevented
- [ ] check for repetition: same actor hitting multiple destinations/resources
- [ ] look for high-risk context: privileged user, crown-jewel segment, admin changes
- [ ] quickly scope: any other entities showing the same indicator(s)

    **platform-specific checks**
    - [ ] review: Cloud Audit Logs (Admin Activity, Data Access where enabled)
- [ ] review: Security Command Center findings (if enabled)
- [ ] review: VPC Flow Logs (network sessions)
- [ ] review: Cloud Logging service logs (GKE, Compute, Cloud Run, etc.)

    ## deep dive (60 minutes)
    - [ ] pivot across related logs to build a single narrative (who → what → where → when)
- [ ] confirm ingress/egress paths and any nat/proxy translation (if applicable)
- [ ] check for persistence attempts (new rules, policy changes, new tokens/keys)
- [ ] look for exfil patterns: bytes_out spikes, long sessions, unusual destinations
- [ ] verify admin/audit logs for unauthorized configuration changes
- [ ] document confidence level (low/med/high) with evidence

    ## what “good” looks like
    - expected destinations/apps for the user/device role
- normal volume and timing aligned to business operations
- policy blocks match expected security posture
- no follow-on suspicious activity in adjacent telemetry

    ## what “suspicious” looks like
    - rare/new destinations, unusual geo/asn, or evasive patterns
- allowed traffic that should normally be blocked by policy
- repeated failures followed by success (auth) or policy changes (config)
- high bytes_out or repeated sessions from sensitive assets
- unauthorized admin actions or newly created access paths

    ## confidence
    - **confidence:** [low/med/high]
    - **why:** [one sentence + evidence links]
