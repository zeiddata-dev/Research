# evidence checklist
    **platform:** AWS

    ## required fields to capture (as available)
    - [ ] eventTime
- [ ] eventName
- [ ] eventSource
- [ ] awsRegion
- [ ] sourceIPAddress
- [ ] userIdentity.type
- [ ] userIdentity.arn
- [ ] userIdentity.accessKeyId
- [ ] requestParameters
- [ ] responseElements
- [ ] errorCode/errorMessage
- [ ] recipientAccountId
- [ ] sessionContext (MFA, role)
- [ ] userAgent
- [ ] resource ARN(s)
- [ ] guardduty_finding_id (if applicable)

    ## chain-of-custody (mini form)
    - **collected by:** [name]
    - **collection time (utc):** [yyyy-mm-dd hh:mm]
    - **source system:** AWS ([console/workspace/index])
    - **export format:** [csv/json/pdf/screenshot]
    - **stored at:** [evidence_repo_path]
    - **integrity (optional):** sha256([filename]) = [hash]

    ## export guidance (high level)
    - export only the minimum necessary [time_range] and entities (user/device/account) to reduce noise.
- prefer raw event exports (json/csv) + a screenshot of filters/time range used.
- record the query/search text (or saved search name) used to generate the export.
- store artifacts in [evidence_repo_path] with consistent naming: [incident_id]_[source]_[utc_range].
- include principal identity and full api method/event names; capture region/project/account details.
