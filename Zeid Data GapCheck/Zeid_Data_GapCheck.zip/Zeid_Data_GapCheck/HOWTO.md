# HOWTO

Run:
```bash
python gapcheck.py run --policy policy.sample.json --output ./evidence
```

Verify bundle integrity:
```bash
python gapcheck.py verify --bundle ./evidence/<bundle_folder>
```
